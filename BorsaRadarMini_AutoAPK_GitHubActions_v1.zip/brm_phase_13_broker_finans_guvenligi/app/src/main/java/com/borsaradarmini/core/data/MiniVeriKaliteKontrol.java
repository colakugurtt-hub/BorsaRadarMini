package com.borsaradarmini.core.data;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class MiniVeriKaliteKontrol {
    public MiniVeriKaliteSonuc kontrolEt(String sembol, String kullanilanFormat, List<MiniMumVerisi> mumlar, boolean tarihZorunlu) {
        if (sembol == null || sembol.trim().isEmpty()) return MiniVeriKaliteSonuc.red("SEMBOL_BOS", "Sembol boş.");
        if (mumlar == null || mumlar.size() < 5) return MiniVeriKaliteSonuc.red("MUM_AZ", "En az 5 günlük mum gerekli.");

        Set<String> tarihler = new HashSet<>();
        double oncekiClose = 0.0;
        for (int i = 0; i < mumlar.size(); i++) {
            MiniMumVerisi m = mumlar.get(i);
            if (m == null || !m.gecerliMi()) return MiniVeriKaliteSonuc.red("OHLC_HATALI", "Geçersiz OHLC/hacim verisi var.");
            if (tarihZorunlu) {
                if (m.datetime == null || m.datetime.trim().isEmpty()) return MiniVeriKaliteSonuc.red("TARIH_YOK", "Twelve Data mum tarihinde datetime yok.");
                if (tarihler.contains(m.datetime)) return MiniVeriKaliteSonuc.red("TEKRAR_TARIH", "Tekrarlanan mum tarihi var: " + m.datetime);
                tarihler.add(m.datetime);
            }
            if (Math.abs(m.gunlukDegisimYuzde()) > 25.0) {
                return MiniVeriKaliteSonuc.red("GUNLUK_SAPMA", "Günlük sapma %25 üzeri; şüpheli veri.");
            }
            if (oncekiClose > 0) {
                double gap = Math.abs((m.close - oncekiClose) / oncekiClose * 100.0);
                if (gap > 35.0) return MiniVeriKaliteSonuc.red("KAPANIS_SAPMA", "Ardışık kapanış sapması %35 üzeri; şüpheli veri.");
            }
            oncekiClose = m.close;
        }

        MiniMumVerisi son = mumlar.get(mumlar.size() - 1);
        String tarih = son.datetime == null || son.datetime.isEmpty() ? "demo/tarih yok" : son.datetime;
        return MiniVeriKaliteSonuc.pass("Veri kalite PASS. Format: " + kullanilanFormat + ", son tarih: " + tarih);
    }
}
