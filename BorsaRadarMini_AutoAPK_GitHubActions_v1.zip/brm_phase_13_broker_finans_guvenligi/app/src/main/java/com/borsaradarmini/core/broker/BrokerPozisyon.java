package com.borsaradarmini.core.broker;

public class BrokerPozisyon {
    public final String sembol;
    public final double giris;
    public final double stop;
    public final double hedef1;
    public final double hedef2;
    public final int adet;
    public final double riskYuzdesi;
    public final double hedef1RiskOdul;
    public double guncelFiyat;
    public PozisyonDurumu durum;
    public double netKarZarar;

    public BrokerPozisyon(String sembol, double giris, double stop, double hedef1, double hedef2, int adet) {
        this(sembol, giris, stop, hedef1, hedef2, adet, 0.0, 0.0);
    }

    public BrokerPozisyon(String sembol, double giris, double stop, double hedef1, double hedef2, int adet,
                          double riskYuzdesi, double hedef1RiskOdul) {
        this.sembol = sembol;
        this.giris = giris;
        this.stop = stop;
        this.hedef1 = hedef1;
        this.hedef2 = hedef2;
        this.adet = adet;
        this.riskYuzdesi = riskYuzdesi;
        this.hedef1RiskOdul = hedef1RiskOdul;
        this.guncelFiyat = giris;
        this.durum = PozisyonDurumu.ACIK;
        this.netKarZarar = 0;
    }

    public double anlikKarZararYuzde() {
        if (giris <= 0) return 0.0;
        return ((guncelFiyat - giris) / giris) * 100.0;
    }
}
