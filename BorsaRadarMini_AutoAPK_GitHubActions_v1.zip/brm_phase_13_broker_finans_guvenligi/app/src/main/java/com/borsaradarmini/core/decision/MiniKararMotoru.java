package com.borsaradarmini.core.decision;

import com.borsaradarmini.core.data.*;
import java.util.List;

public class MiniKararMotoru {
    private static final int MIN_GERCEK_MUM = 20;

    public MiniKararSonuc kararVer(MiniVeriSonuc veri) {
        if (veri == null || !veri.basariliMi() || veri.mumlarOku().size() < MIN_GERCEK_MUM || veri.sonMum() == null) {
            String s = veri == null ? "BILINMIYOR" : veri.sembol;
            String mesaj = veri == null ? "Yeterli veri yok." : veri.mesaj;
            if (veri != null && veri.mumlarOku().size() < MIN_GERCEK_MUM) {
                mesaj = mesaj + " | Sinyal kilidi: En az " + MIN_GERCEK_MUM + " gerçek günlük mum yok. Gelen mum: " + veri.mumlarOku().size();
            }
            return new MiniKararSonuc(s, KararEtiketi.VERI_YETERSIZ, RiskSeviyesi.BELIRSIZ,
                    veri == null ? VeriKaynagi.YOK : veri.veriKaynagi, false, 0,
                    "İşlem açılmaz", mesaj, 0, 0, 0, 0);
        }

        MiniMumVerisi son = veri.sonMum();
        if (!son.gecerliMi()) {
            return new MiniKararSonuc(veri.sembol, KararEtiketi.VERI_YETERSIZ, RiskSeviyesi.BELIRSIZ,
                    veri.veriKaynagi, false, 0, "İşlem açılmaz",
                    "Veri kalite kontrolünden geçmedi. " + veri.mesaj, 0, 0, 0, 0);
        }

        List<MiniMumVerisi> m = veri.mumlarOku();
        String kanit = veriKaniti(veri);

        double close = son.close;
        double avg5 = avgClose(m, 5);
        double avg10 = avgClose(m, 10);
        double son5Getiri = yuzde(close - m.get(m.size() - 5).close, m.get(m.size() - 5).close);
        double hacimOrani = hacimOrani(m);

        double puan = 0;
        if (close > avg5) puan += 25;
        if (close > avg10) puan += 20;
        if (son5Getiri > 1 && son5Getiri <= 8) puan += 20;
        if (hacimOrani >= 0.85) puan += 15;
        if (veri.veriKaynagi == VeriKaynagi.TWELVE_DATA) puan += 20;

        double giris = close;
        double stop = close * 0.95;
        double hedef1 = close * 1.10;
        double hedef2 = close * 1.15;

        if (veri.veriKaynagi != VeriKaynagi.TWELVE_DATA) {
            return new MiniKararSonuc(veri.sembol, KararEtiketi.IZLE, RiskSeviyesi.ORTA, veri.veriKaynagi,
                    false, Math.min(puan, 69), "Yedek/demo veriyle sadece izlenir",
                    "Broker kapalı. Gerçek Twelve Data kanıtı yok. " + kanit, giris, stop, hedef1, hedef2);
        }

        if (son5Getiri > 12) {
            return new MiniKararSonuc(veri.sembol, KararEtiketi.IZLE, RiskSeviyesi.YUKSEK, veri.veriKaynagi,
                    false, puan, "Kovalanmaz", "Fiyat kısa sürede fazla yükselmiş. " + kanit, giris, stop, hedef1, hedef2);
        }

        if (puan >= 75) {
            return new MiniKararSonuc(veri.sembol, KararEtiketi.AL_ADAYI, RiskSeviyesi.ORTA, veri.veriKaynagi,
                    true, puan, "Geri çekilmede takip edilir",
                    "AL adayı; en iyi 3 filtresine girebilir. " + kanit, giris, stop, hedef1, hedef2);
        }

        if (puan >= 55) {
            return new MiniKararSonuc(veri.sembol, KararEtiketi.IZLE, RiskSeviyesi.ORTA, veri.veriKaynagi,
                    false, puan, "İzlenebilir", "Güç var ama AL için yeterli değil. " + kanit, giris, stop, hedef1, hedef2);
        }

        if (puan >= 35) {
            return new MiniKararSonuc(veri.sembol, KararEtiketi.BEKLE, RiskSeviyesi.BELIRSIZ, veri.veriKaynagi,
                    false, puan, "Bekle", "Net avantaj yok. " + kanit, giris, stop, hedef1, hedef2);
        }

        return new MiniKararSonuc(veri.sembol, KararEtiketi.UZAK_DUR, RiskSeviyesi.YUKSEK, veri.veriKaynagi,
                false, puan, "Uzak dur", "Radar kriterleri zayıf. " + kanit, giris, stop, hedef1, hedef2);
    }

    private String veriKaniti(MiniVeriSonuc veri) {
        List<MiniMumVerisi> m = veri.mumlarOku();
        MiniMumVerisi son = m.get(m.size() - 1);
        MiniMumVerisi onceki = m.get(m.size() - 2);
        String tarih = son.datetime == null || son.datetime.isEmpty() ? "tarih yok" : son.datetime;
        double degisim = yuzde(son.close - onceki.close, onceki.close);
        return "Veri kanıtı: Kaynak=" + veri.veriKaynagi
                + ", Mum=" + m.size()
                + ", Son tarih=" + tarih
                + ", Son kapanış=" + fmt(son.close)
                + ", Önceki kapanış=" + fmt(onceki.close)
                + ", Değişim=%" + fmt(degisim)
                + ", Son hacim=" + son.volume
                + ", Kalite=PASS.";
    }

    private double avgClose(List<MiniMumVerisi> m, int n) {
        int start = Math.max(0, m.size() - n);
        double sum = 0; int count = 0;
        for (int i = start; i < m.size(); i++) { sum += m.get(i).close; count++; }
        return count == 0 ? 0 : sum / count;
    }

    private double hacimOrani(List<MiniMumVerisi> m) {
        if (m.size() < 2) return 1.0;
        MiniMumVerisi son = m.get(m.size() - 1);
        int start = Math.max(0, m.size() - 6);
        long sum = 0; int count = 0;
        for (int i = start; i < m.size() - 1; i++) { sum += m.get(i).volume; count++; }
        return count == 0 || sum <= 0 ? 1.0 : son.volume / ((double) sum / count);
    }

    private double yuzde(double fark, double baz) {
        return baz == 0 ? 0 : (fark / baz) * 100.0;
    }

    private String fmt(double v) {
        return String.format(java.util.Locale.US, "%.2f", v);
    }
}
