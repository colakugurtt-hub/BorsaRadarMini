package com.borsaradarmini.core.data;

public class MiniMumVerisi {
    public final String datetime;
    public final double open;
    public final double high;
    public final double low;
    public final double close;
    public final long volume;

    public MiniMumVerisi(double open, double high, double low, double close, long volume) {
        this("", open, high, low, close, volume);
    }

    public MiniMumVerisi(String datetime, double open, double high, double low, double close, long volume) {
        this.datetime = datetime == null ? "" : datetime.trim();
        this.open = open;
        this.high = high;
        this.low = low;
        this.close = close;
        this.volume = volume;
    }

    public boolean gecerliMi() {
        return open > 0 && high > 0 && low > 0 && close > 0
                && high >= low && high >= open && high >= close
                && low <= open && low <= close && volume > 0;
    }

    public double gunlukDegisimYuzde() {
        if (open <= 0) return 0.0;
        return ((close - open) / open) * 100.0;
    }
}
