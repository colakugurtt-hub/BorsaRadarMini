package com.borsaradarmini.core.broker;

import com.borsaradarmini.core.finance.*;
import java.util.ArrayList;
import java.util.List;

public class MiniSanalBroker {
    public double bakiye = 100000.0;
    public final List<BekleyenSinyal> bekleyenler = new ArrayList<>();
    public final List<BrokerPozisyon> aciklar = new ArrayList<>();
    public final List<BrokerPozisyon> kapananlar = new ArrayList<>();
    private final MiniFinansMotoru finans = new MiniFinansMotoru();

    public void bekleyenSinyalEkle(BekleyenSinyal s) {
        if (s == null) return;
        if (!bekleyenVarMi(s.sembol) && !acikPozisyonVarMi(s.sembol)) bekleyenler.add(s);
    }

    public boolean bekleyenVarMi(String sembol) {
        for (BekleyenSinyal s : bekleyenler) if (s.sembol.equals(sembol) && s.durum == BekleyenSinyalDurumu.ON_BES_DK_BEKLIYOR) return true;
        return false;
    }

    public boolean acikPozisyonVarMi(String sembol) {
        for (BrokerPozisyon p : aciklar) if (p.sembol.equals(sembol) && p.durum == PozisyonDurumu.ACIK) return true;
        return false;
    }

    public String bekleyenleriOnaylaVePozisyonAc() {
        return onBesDkKontrolSimuleEtVePozisyonAc();
    }

    public String onBesDkKontrolSimuleEtVePozisyonAc() {
        int acilan = 0;
        int iptal = 0;
        for (BekleyenSinyal s : bekleyenler) {
            if (s.durum != BekleyenSinyalDurumu.ON_BES_DK_BEKLIYOR) continue;

            if (acikPozisyonVarMi(s.sembol)) {
                s.durum = BekleyenSinyalDurumu.IPTAL_EDILDI;
                s.redSebebi = "Aynı hissede açık pozisyon var.";
                iptal++;
                continue;
            }
            if (aciklar.size() >= 3) {
                s.durum = BekleyenSinyalDurumu.IPTAL_EDILDI;
                s.redSebebi = "Maksimum 3 açık pozisyon limiti dolu.";
                iptal++;
                continue;
            }

            s.kontrolFiyati = simuleKontrolFiyati(s);
            s.kontrolKaniti = "15 dk simülasyon kontrolü: ilk fiyat " + fmt(s.ilkSinyalFiyati)
                    + ", kontrol fiyatı " + fmt(s.kontrolFiyati) + ".";

            MiniFinansSonuc fs = finans.degerlendir(MiniFinansIstek.al(s.sembol, s.kontrolFiyati, s.stop, s.hedef1, s.hedef2, 10000, 0.0004));
            if (!fs.gecerliMi) {
                s.durum = BekleyenSinyalDurumu.IPTAL_EDILDI;
                s.redSebebi = "15 dk sonrası finans matematiği RED: " + fs.ozetMetin;
                iptal++;
                continue;
            }

            BrokerPozisyon p = new BrokerPozisyon(s.sembol, s.kontrolFiyati, s.stop, s.hedef1, s.hedef2,
                    fs.adet, fs.riskYuzdesi, fs.hedef1RiskOdul);
            aciklar.add(p);
            s.durum = BekleyenSinyalDurumu.BROKERE_AKTARILDI;
            s.redSebebi = "";
            acilan++;
        }
        return acilan + " sanal pozisyon açıldı, " + iptal + " sinyal iptal edildi.";
    }

    private double simuleKontrolFiyati(BekleyenSinyal s) {
        double fiyat = s.giris * 1.005;
        if (fiyat >= s.hedef1) fiyat = s.giris;
        return Math.round(fiyat * 100.0) / 100.0;
    }

    public String demoFiyatGuncelle() {
        int kapanan = 0;
        List<BrokerPozisyon> kapat = new ArrayList<>();
        for (BrokerPozisyon p : aciklar) {
            p.guncelFiyat = p.hedef1;
            MiniFinansSonuc fs = finans.degerlendir(MiniFinansIstek.al(p.sembol, p.giris, p.stop, p.hedef1, p.hedef2, 10000, 0.0004));
            p.durum = PozisyonDurumu.HEDEF_1_GELDI;
            p.netKarZarar = fs.hedef1NetKar;
            bakiye = Math.round((bakiye + p.netKarZarar) * 100.0) / 100.0;
            kapat.add(p);
            kapanan++;
        }
        aciklar.removeAll(kapat);
        kapananlar.addAll(kapat);
        return kapanan + " pozisyon hedef 1 ile kapandı.";
    }

    private String fmt(double v) {
        return String.format(java.util.Locale.US, "%.2f", v);
    }
}
