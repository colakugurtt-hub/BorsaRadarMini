package com.borsaradarmini.core.data;

public class MiniVeriKaliteSonuc {
    public final boolean gecerli;
    public final String kod;
    public final String mesaj;

    private MiniVeriKaliteSonuc(boolean gecerli, String kod, String mesaj) {
        this.gecerli = gecerli;
        this.kod = kod;
        this.mesaj = mesaj;
    }

    public static MiniVeriKaliteSonuc pass(String mesaj) {
        return new MiniVeriKaliteSonuc(true, "PASS", mesaj);
    }

    public static MiniVeriKaliteSonuc red(String kod, String mesaj) {
        return new MiniVeriKaliteSonuc(false, kod, mesaj);
    }
}
