package com.borsaradarmini.core.broker;

import com.borsaradarmini.core.decision.MiniKararSonuc;

public class BekleyenSinyal {
    public final String sembol;
    public final double ilkSinyalFiyati;
    public final double giris;
    public final double stop;
    public final double hedef1;
    public final double hedef2;
    public double kontrolFiyati;
    public String kontrolKaniti;
    public String redSebebi;
    public BekleyenSinyalDurumu durum;

    public BekleyenSinyal(MiniKararSonuc k) {
        this.sembol = k.sembol;
        this.ilkSinyalFiyati = k.girisFiyati;
        this.giris = k.girisFiyati;
        this.stop = k.stopFiyati;
        this.hedef1 = k.hedef1Fiyati;
        this.hedef2 = k.hedef2Fiyati;
        this.kontrolFiyati = 0.0;
        this.kontrolKaniti = "15 dk kontrol bekliyor.";
        this.redSebebi = "";
        this.durum = BekleyenSinyalDurumu.ON_BES_DK_BEKLIYOR;
    }
}
