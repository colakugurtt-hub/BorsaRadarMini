package com.borsaradarmini.core.data;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URLEncoder;
import java.net.URL;

public class MiniTwelveDataClient {
    private static final String BASE = "https://api.twelvedata.com/time_series";

    public MiniHttpYaniti timeSeriesDaily(String sembolFormat, String apiKey) {
        if (apiKey == null || apiKey.trim().isEmpty()) {
            return new MiniHttpYaniti(0, null, "API key boş.");
        }
        try {
            String url = BASE
                    + "?symbol=" + enc(sembolFormat)
                    + "&interval=1day"
                    + "&outputsize=30"
                    + "&apikey=" + enc(apiKey.trim());
            HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
            c.setRequestMethod("GET");
            c.setConnectTimeout(12000);
            c.setReadTimeout(12000);
            int code = c.getResponseCode();
            InputStream is = code >= 200 && code < 300 ? c.getInputStream() : c.getErrorStream();
            String body = readAll(is);
            c.disconnect();
            if (code == 429 || (body != null && body.contains("\"code\":429"))) {
                MiniApiKotaGuvenligi.kotaHatasiAlindi();
                return new MiniHttpYaniti(code, body, "Twelve Data dakikalık kota doldu. 60 saniye bekleyin.");
            }

            return new MiniHttpYaniti(code, body, code >= 200 && code < 300 ? null : "HTTP " + code);
        } catch (Exception e) {
            return new MiniHttpYaniti(0, null, e.getMessage());
        }
    }

    private String enc(String v) throws Exception { return URLEncoder.encode(v, "UTF-8"); }
    private String readAll(InputStream is) throws Exception {
        if (is == null) return "";
        BufferedReader br = new BufferedReader(new InputStreamReader(is, "UTF-8"));
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = br.readLine()) != null) sb.append(line);
        return sb.toString();
    }
}
