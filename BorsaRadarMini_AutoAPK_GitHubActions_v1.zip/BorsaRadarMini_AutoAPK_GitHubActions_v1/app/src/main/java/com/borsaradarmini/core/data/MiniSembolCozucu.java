package com.borsaradarmini.core.data;

import java.util.ArrayList;
import java.util.List;

public class MiniSembolCozucu {
    public List<String> twelveDataAdaylari(String bistSembol) {
        String temiz = bistSembol == null ? "" : bistSembol.trim().toUpperCase();
        List<String> adaylar = new ArrayList<>();
        if (temiz.isEmpty()) return adaylar;

        // Grow 55 kota güvenliği:
        // Aynı hisse için ASTOR, ASTOR:XIST, ASTOR.IS gibi 3 deneme yapılmaz.
        // Önceki çalışan mobil testte veri düz sembol ile geliyordu.
        // Bu nedenle tek istek: ASTOR / DOAS / BIMAS gibi düz BIST sembolü.
        adaylar.add(temiz);
        return adaylar;
    }
}
