package com.borsaradarmini.core.data;

import java.util.ArrayList;
import java.util.List;

public class MiniSembolCozucu {
    public List<String> twelveDataAdaylari(String bistSembol) {
        String temiz = bistSembol == null ? "" : bistSembol.trim().toUpperCase();
        List<String> adaylar = new ArrayList<>();
        if (temiz.isEmpty()) return adaylar;

        // Kota güvenliği:
        // Eski yapı aynı sembol için ASTOR, ASTOR:XIST, ASTOR.IS şeklinde 3 istek atabiliyordu.
        // Grow 55 dakikalık limitte bu tehlikeli. Bu yüzden tek güvenli XIST formatı kullanılır.
        adaylar.add(temiz + ":XIST");
        return adaylar;
    }
}
