package com.borsaradarmini.core.data;

public final class MiniApiKotaGuvenligi {
    private static final long COOLDOWN_MS = 60_000L;
    private static long cooldownUntilMs = 0L;
    private static String sonMesaj = "";

    private MiniApiKotaGuvenligi() { }

    public static synchronized boolean istekYapilabilirMi() {
        return System.currentTimeMillis() >= cooldownUntilMs;
    }

    public static synchronized void istekBasladi() {
        cooldownUntilMs = System.currentTimeMillis() + COOLDOWN_MS;
        sonMesaj = "Son veri isteği sonrası 60 saniye güvenlik beklemesi başladı.";
    }

    public static synchronized void kotaHatasiAlindi() {
        cooldownUntilMs = System.currentTimeMillis() + COOLDOWN_MS;
        sonMesaj = "Twelve Data dakikalık kota doldu. Veri güvenliği için bekleniyor.";
    }

    public static synchronized long kalanSaniye() {
        long kalan = cooldownUntilMs - System.currentTimeMillis();
        if (kalan <= 0L) return 0L;
        return Math.max(1L, (kalan + 999L) / 1000L);
    }

    public static synchronized String beklemeMesaji() {
        long kalan = kalanSaniye();
        if (kalan <= 0L) return "Kota güvenliği hazır. Yeni veri çekilebilir.";
        String temel = sonMesaj == null || sonMesaj.trim().isEmpty()
                ? "Kota güvenliği aktif."
                : sonMesaj;
        return temel + " Kalan süre: " + kalan + " saniye.";
    }

    public static synchronized String durumMesaji() {
        long kalan = kalanSaniye();
        if (kalan <= 0L) return "Kota güvenliği: hazır.";
        return "Kota güvenliği: " + kalan + " sn bekle.";
    }
}
