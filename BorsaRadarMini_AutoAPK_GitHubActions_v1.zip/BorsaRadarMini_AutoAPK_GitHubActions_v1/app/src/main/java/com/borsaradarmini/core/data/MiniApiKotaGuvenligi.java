package com.borsaradarmini.core.data;

public class MiniApiKotaGuvenligi {
    private static final long COOLDOWN_MS = 60_000L;
    private static long lastApiAttemptMs = 0L;
    private static long cooldownUntilMs = 0L;
    private static String lastBlockReason = "";

    public static synchronized boolean istekYapilabilirMi() {
        long now = System.currentTimeMillis();
        return now >= cooldownUntilMs;
    }

    public static synchronized long kalanSaniye() {
        long now = System.currentTimeMillis();
        long kalanMs = cooldownUntilMs - now;
        if (kalanMs <= 0) return 0L;
        return Math.max(1L, (kalanMs + 999L) / 1000L);
    }

    public static synchronized void istekBasladi() {
        long now = System.currentTimeMillis();
        lastApiAttemptMs = now;
        cooldownUntilMs = now + COOLDOWN_MS;
        lastBlockReason = "";
    }

    public static synchronized void kotaHatasiAlindi() {
        long now = System.currentTimeMillis();
        cooldownUntilMs = now + COOLDOWN_MS;
        lastBlockReason = "Twelve Data dakikalık kota doldu. Veri güvenliği için yeni veri çekilmedi.";
    }

    public static synchronized String beklemeMesaji() {
        long kalan = kalanSaniye();
        if (kalan <= 0) {
            return "Kota güvenliği açık. Yeni veri çekilebilir.";
        }
        if (lastBlockReason != null && !lastBlockReason.isEmpty()) {
            return lastBlockReason + " Yaklaşık " + kalan + " saniye sonra tekrar deneyin.";
        }
        return "Kota güvenliği aktif. Veri güvenliği için bekleniyor. Kalan süre: " + kalan + " saniye.";
    }

    public static synchronized String durumMesaji() {
        long kalan = kalanSaniye();
        if (kalan <= 0) return "Kota güvenliği: hazır.";
        return "Kota güvenliği: " + kalan + " sn bekle.";
    }

    public static synchronized long sonIstekZamani() {
        return lastApiAttemptMs;
    }
}
