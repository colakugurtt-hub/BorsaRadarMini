# CHANGELOG

## v2.0-faz12.1

- Twelve Data sembol çözümleme sırası eklendi: BIMAS → BIMAS:XIST → BIMAS.IS.
- İlk tercih yalın BIST sembolü yapıldı.
- Başarısız sembol formatlarının gerçek hata mesajı toplanıyor.
- Veri yetersiz kartlarında gerçek hata detayı gösteriliyor.
- Radar ekranına `BIMAS tek sembol test et` butonu eklendi.
- BIST30 toplu taramadan önce tek sembol doğrulama akışı eklendi.
