# Faz 11 — GitHub Actions APK Test Planı

## 1. Repo Kontrolü

GitHub repo içinde şu dosyalar olmalı:

```text
.github/workflows/build-v2-apk.yml
app/build.gradle
settings.gradle
build.gradle
app/src/main/AndroidManifest.xml
app/src/main/java/com/borsaradarmini/MainActivity.java
```

## 2. Actions Kontrolü

Workflow adı:

```text
Build BorsaRadarMini v2 APK
```

Beklenen sonuç:

```text
Yeşil tik
```

## 3. APK Artifact Kontrolü

Artifact adı:

```text
BorsaRadarMini-v2-debug-apk
```

APK yolu:

```text
app/build/outputs/apk/debug/app-debug.apk
```

## 4. Telefon Kontrolü

APK kurulduktan sonra kontrol edilecekler:

```text
Ana Radar açılıyor mu?
ONAYLI AL kartları görünüyor mu?
Hisse Detay açılıyor mu?
Sanal Broker ekranı açılıyor mu?
15 dk kontrolü simüle et butonu çalışıyor mu?
Demo fiyat güncelle: Hedef 1 kapat butonu çalışıyor mu?
Ayarlar ekranında API key kaydediliyor mu?
```

## 5. Faz 11 PASS Kriteri

Faz 11 PASS için:

```text
GitHub Actions yeşil tik verecek
APK artifact oluşacak
APK telefona kurulacak
Uygulama açılacak
4 ekran gezilecek
API key kaydedilecek
Sanal broker demo akışı çalışacak
```
