# Borsa Radar Mini v2 — Birleşik Faz 10 SPEC

Bu proje KararMotoru ile bağlantılı değildir.

## Kapsam

- Kişisel telefon APK uygulaması
- BIST30 mini radar
- ONAYLI AL / AL ADAYI / İZLE / BEKLE / UZAK DUR / VERİ YETERSİZ
- 15 dakika bekleyen sinyal mantığı
- Mini sanal broker
- API key saklama
- Bildirim metni üretimi

## Faz 10 Sınırı

Faz 10, birleşik Android proje ve GitHub Actions APK üretim paketidir.

Gerçek Twelve Data HTTP bağlantısı sonraki fazda demo veri motorunun yerine bağlanacaktır.
