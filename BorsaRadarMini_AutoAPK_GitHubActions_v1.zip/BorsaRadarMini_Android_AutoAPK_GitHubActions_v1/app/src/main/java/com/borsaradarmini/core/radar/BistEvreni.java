package com.borsaradarmini.core.radar;

public enum BistEvreni {
    BIST30,
    BIST50,
    BIST100
}
