package com.borsaradarmini.core.finance;

public class ParaMatematigi {
    public static double round2(double v) {
        return Math.round(v * 100.0) / 100.0;
    }

    public static double yuzde(double fark, double baz) {
        if (baz == 0) return 0.0;
        return (fark / baz) * 100.0;
    }

    public static int tamAdet(double tutar, double fiyat) {
        if (tutar <= 0 || fiyat <= 0) return 0;
        return (int)Math.floor(tutar / fiyat);
    }

    public static double komisyon(double tutar, double oran) {
        return round2(tutar * oran);
    }

    public static double alNetKarZarar(double giris, double cikis, int adet, double girisKomisyonu, double komisyonOrani) {
        double cikisKomisyonu = (cikis * adet) * komisyonOrani;
        return round2((cikis - giris) * adet - girisKomisyonu - cikisKomisyonu);
    }
}
