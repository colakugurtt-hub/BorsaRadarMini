package com.borsaradarmini.core.decision;

import java.util.ArrayList;
import java.util.List;

public class MiniSinyalGuvenlikKapisi {
    public static class Sonuc {
        public final boolean gecer;
        public final String neden;

        public Sonuc(boolean gecer, String neden) {
            this.gecer = gecer;
            this.neden = neden;
        }
    }

    public Sonuc kontrolEt(double giris, double stop, double hedef1, double hedef2, double sonKapanis, double sonOnGunDusuk, double sonOnGunYuksek) {
        List<String> blok = new ArrayList<>();

        if (giris <= 0 || stop <= 0 || hedef1 <= 0 || hedef2 <= 0 || sonKapanis <= 0) {
            blok.add("Fiyat alanları geçersiz.");
        }

        if (stop >= giris) {
            blok.add("Stop giriş fiyatının altında değil.");
        }

        double stopMesafesi = giris > 0 ? (giris - stop) / giris : 1.0;
        double hedef1Getiri = giris > 0 ? (hedef1 - giris) / giris : 0.0;
        double rr = stopMesafesi > 0 ? hedef1Getiri / stopMesafesi : 0.0;

        if (stopMesafesi > 0.07) {
            blok.add("Stop mesafesi geniş: %" + yuvarla(stopMesafesi * 100));
        }

        if (stopMesafesi < 0.012) {
            blok.add("Stop mesafesi çok dar: %" + yuvarla(stopMesafesi * 100));
        }

        if (rr < 1.50) {
            blok.add("Risk/ödül zayıf: " + yuvarla(rr));
        }

        if (hedef1Getiri > 0.12) {
            blok.add("Hedef 1 günlük sistem için fazla iyimser: %" + yuvarla(hedef1Getiri * 100));
        }

        double aralik = sonOnGunYuksek - sonOnGunDusuk;
        if (aralik > 0) {
            double konum = (sonKapanis - sonOnGunDusuk) / aralik;
            if (konum > 0.88) {
                blok.add("Fiyat son 10 günlük aralığın tepesine yakın, kovalanmaz.");
            }
        }

        if (!blok.isEmpty()) {
            return new Sonuc(false, birlestir(blok));
        }
        return new Sonuc(true, "Güvenlik kapıları geçti. Stop, hedef ve risk/ödül makul.");
    }

    private String birlestir(List<String> list) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < list.size(); i++) {
            if (i > 0) sb.append(" ");
            sb.append(list.get(i));
        }
        return sb.toString();
    }

    private String yuvarla(double v) {
        return String.format(java.util.Locale.US, "%.2f", v);
    }
}
