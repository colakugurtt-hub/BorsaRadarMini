package com.borsaradarmini.core.finance;

import java.util.ArrayList;
import java.util.List;

public class MiniFinansMotoru {
    public MiniFinansSonuc degerlendir(MiniFinansIstek i) {
        List<RedSebebi> red = new ArrayList<>();
        if (i == null) {
            red.add(RedSebebi.BILINMEYEN_YON);
            return sonuc(false, red, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "İstek boş.");
        }
        if (i.sembol == null || i.sembol.trim().isEmpty()) red.add(RedSebebi.SEMBOL_BOS);
        if (i.komisyonOrani < 0) red.add(RedSebebi.KOMISYON_HATALI);
        if (i.girisFiyati <= 0) red.add(RedSebebi.GIRIS_POZITIF_DEGIL);
        if (i.stopFiyati <= 0) red.add(RedSebebi.STOP_POZITIF_DEGIL);
        if (i.hedef1Fiyati <= 0) red.add(RedSebebi.HEDEF1_POZITIF_DEGIL);
        if (i.hedef2Fiyati <= 0) red.add(RedSebebi.HEDEF2_POZITIF_DEGIL);

        if (i.islemYonu == IslemYonu.AL) {
            if (!(i.stopFiyati < i.girisFiyati && i.girisFiyati < i.hedef1Fiyati)) red.add(RedSebebi.AL_YON_MATEMATIGI_HATALI);
            if (!(i.hedef1Fiyati <= i.hedef2Fiyati)) red.add(RedSebebi.HEDEF_SIRALAMASI_HATALI);
        } else if (i.islemYonu == IslemYonu.SHORT) {
            if (!(i.hedef1Fiyati < i.girisFiyati && i.girisFiyati < i.stopFiyati)) red.add(RedSebebi.SHORT_YON_MATEMATIGI_HATALI);
            if (!(i.hedef2Fiyati <= i.hedef1Fiyati)) red.add(RedSebebi.HEDEF_SIRALAMASI_HATALI);
        } else {
            red.add(RedSebebi.BILINMEYEN_YON);
        }

        if (!red.isEmpty()) return sonuc(false, red, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "Finans matematiği RED.");

        double risk = i.islemYonu == IslemYonu.AL
                ? ParaMatematigi.yuzde(i.girisFiyati - i.stopFiyati, i.girisFiyati)
                : ParaMatematigi.yuzde(i.stopFiyati - i.girisFiyati, i.girisFiyati);

        double getiri1 = i.islemYonu == IslemYonu.AL
                ? ParaMatematigi.yuzde(i.hedef1Fiyati - i.girisFiyati, i.girisFiyati)
                : ParaMatematigi.yuzde(i.girisFiyati - i.hedef1Fiyati, i.girisFiyati);

        double getiri2 = i.islemYonu == IslemYonu.AL
                ? ParaMatematigi.yuzde(i.hedef2Fiyati - i.girisFiyati, i.girisFiyati)
                : ParaMatematigi.yuzde(i.girisFiyati - i.hedef2Fiyati, i.girisFiyati);

        double r1 = risk == 0 ? 0 : getiri1 / risk;
        double r2 = risk == 0 ? 0 : getiri2 / risk;

        if (risk < i.minimumRiskYuzdesi) red.add(RedSebebi.RISK_COK_DUSUK);
        if (risk > i.maksimumRiskYuzdesi) red.add(RedSebebi.RISK_COK_YUKSEK);
        if (r1 < i.minimumRiskOdul) red.add(RedSebebi.RISK_ODUL_ZAYIF);
        if (i.islemBasiSanalTutar < i.girisFiyati) red.add(RedSebebi.ISLEM_TUTARI_YETERSIZ);

        int adet = ParaMatematigi.tamAdet(i.islemBasiSanalTutar, i.girisFiyati);
        if (adet < 1) red.add(RedSebebi.ADET_YETERSIZ);

        double kullanilan = ParaMatematigi.round2(adet * i.girisFiyati);
        double girisKom = ParaMatematigi.komisyon(kullanilan, i.komisyonOrani);
        double hedef1Net = ParaMatematigi.alNetKarZarar(i.girisFiyati, i.hedef1Fiyati, adet, girisKom, i.komisyonOrani);
        double hedef2Net = ParaMatematigi.alNetKarZarar(i.girisFiyati, i.hedef2Fiyati, adet, girisKom, i.komisyonOrani);
        double stopNet = ParaMatematigi.alNetKarZarar(i.girisFiyati, i.stopFiyati, adet, girisKom, i.komisyonOrani);

        boolean ok = red.isEmpty();
        return sonuc(ok, red, adet, kullanilan, risk, getiri1, getiri2, r1, r2, girisKom,
                hedef1Net, hedef2Net, stopNet, ok ? "İşlem matematiksel olarak geçerli." : "Finans matematiği RED.");
    }

    public double alNetKapanis(double giris, double cikis, int adet, double girisKomisyonu, double komisyonOrani) {
        return ParaMatematigi.alNetKarZarar(giris, cikis, adet, girisKomisyonu, komisyonOrani);
    }

    private MiniFinansSonuc sonuc(boolean ok, List<RedSebebi> red, int adet, double kullanilan,
                                  double risk, double g1, double g2, double r1, double r2, double girisKom,
                                  double h1Net, double h2Net, double stopNet, String metin) {
        return new MiniFinansSonuc(ok, red, adet, ParaMatematigi.round2(kullanilan), ParaMatematigi.round2(risk),
                ParaMatematigi.round2(g1), ParaMatematigi.round2(g2), ParaMatematigi.round2(r1),
                ParaMatematigi.round2(r2), ParaMatematigi.round2(girisKom), ParaMatematigi.round2(h1Net),
                ParaMatematigi.round2(h2Net), ParaMatematigi.round2(stopNet), metin);
    }
}
