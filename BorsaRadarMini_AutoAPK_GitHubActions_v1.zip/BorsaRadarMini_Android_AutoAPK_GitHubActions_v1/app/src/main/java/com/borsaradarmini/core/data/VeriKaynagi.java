package com.borsaradarmini.core.data;

public enum VeriKaynagi {
    TWELVE_DATA,
    YAHOO_YEDEK,
    YOK
}
