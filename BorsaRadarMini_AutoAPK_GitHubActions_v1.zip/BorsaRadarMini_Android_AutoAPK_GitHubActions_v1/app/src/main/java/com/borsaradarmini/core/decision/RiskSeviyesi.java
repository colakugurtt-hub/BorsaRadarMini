package com.borsaradarmini.core.decision;

public enum RiskSeviyesi {
    DUSUK,
    ORTA,
    YUKSEK,
    BELIRSIZ
}
