package com.borsaradarmini.core.decision;

public enum KararEtiketi {
    ONAYLI_AL,
    AL_ADAYI,
    IZLE,
    BEKLE,
    SAT_POZISYON_KAPAT,
    SHORT_ADAYI,
    SHORT_ONAYLI,
    UZAK_DUR,
    VERI_YETERSIZ
}
