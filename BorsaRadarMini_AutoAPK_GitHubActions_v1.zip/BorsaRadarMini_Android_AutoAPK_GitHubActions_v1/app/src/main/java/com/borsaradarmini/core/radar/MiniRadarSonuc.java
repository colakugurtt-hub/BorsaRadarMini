package com.borsaradarmini.core.radar;

import com.borsaradarmini.core.decision.MiniKararSonuc;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class MiniRadarSonuc {
    public final List<MiniKararSonuc> kararlar;
    public final MiniRadarOzet ozet;

    public MiniRadarSonuc(List<MiniKararSonuc> kararlar, MiniRadarOzet ozet) {
        this.kararlar = new ArrayList<>(kararlar);
        this.ozet = ozet;
    }

    public List<MiniKararSonuc> kararlarOku() {
        return Collections.unmodifiableList(kararlar);
    }
}
