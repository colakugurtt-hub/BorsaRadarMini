package com.borsaradarmini.core.broker;

import com.borsaradarmini.core.decision.MiniKararSonuc;

public class BekleyenSinyal {
    public final String sembol;
    public final double giris;
    public final double stop;
    public final double hedef1;
    public final double hedef2;
    public BekleyenSinyalDurumu durum;

    public BekleyenSinyal(MiniKararSonuc k) {
        this.sembol = k.sembol;
        this.giris = k.girisFiyati;
        this.stop = k.stopFiyati;
        this.hedef1 = k.hedef1Fiyati;
        this.hedef2 = k.hedef2Fiyati;
        this.durum = BekleyenSinyalDurumu.ON_BES_DK_BEKLIYOR;
    }
}
