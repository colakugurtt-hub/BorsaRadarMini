package com.borsaradarmini.core.data;

import java.util.ArrayList;
import java.util.List;

public class MiniSembolCozucu {
    public List<String> twelveDataAdaylari(String bistSembol) {
        String temiz = bistSembol == null ? "" : bistSembol.trim().toUpperCase();
        List<String> adaylar = new ArrayList<>();
        if (temiz.isEmpty()) return adaylar;
        adaylar.add(temiz);        // 1) KararMotoru test geçmişine göre ilk tercih: BIMAS
        adaylar.add(temiz + ":XIST"); // 2) Twelve Data exchange formatı
        adaylar.add(temiz + ".IS");   // 3) Son çare Yahoo/BIST tarzı
        return adaylar;
    }
}
