package com.borsaradarmini.core.data;

public class MiniHttpYaniti {
    public final int statusCode;
    public final String body;
    public final String hata;

    public MiniHttpYaniti(int statusCode, String body, String hata) {
        this.statusCode = statusCode;
        this.body = body;
        this.hata = hata;
    }

    public boolean basariliMi() {
        return statusCode >= 200 && statusCode < 300 && body != null && !body.trim().isEmpty();
    }
}
