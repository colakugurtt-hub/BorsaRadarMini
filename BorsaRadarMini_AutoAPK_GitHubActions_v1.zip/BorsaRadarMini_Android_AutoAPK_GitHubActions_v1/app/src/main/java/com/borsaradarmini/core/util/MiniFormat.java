package com.borsaradarmini.core.util;

import java.text.NumberFormat;
import java.util.Locale;

public class MiniFormat {
    private static final Locale TR = new Locale("tr", "TR");

    public static String fiyat(double v) {
        NumberFormat nf = NumberFormat.getNumberInstance(TR);
        nf.setMinimumFractionDigits(2);
        nf.setMaximumFractionDigits(2);
        return nf.format(v);
    }

    public static String tl(double v) {
        return fiyat(v) + " TL";
    }
}
