package com.borsaradarmini.core.decision;

import com.borsaradarmini.core.data.VeriKaynagi;

public class MiniKararSonuc {
    public final String sembol;
    public final KararEtiketi karar;
    public final RiskSeviyesi risk;
    public final VeriKaynagi veriKaynagi;
    public final boolean sanalBrokerAdayi;
    public final double puan;
    public final String islemFikri;
    public final String aciklama;
    public final double girisFiyati;
    public final double stopFiyati;
    public final double hedef1Fiyati;
    public final double hedef2Fiyati;

    public MiniKararSonuc(String sembol, KararEtiketi karar, RiskSeviyesi risk, VeriKaynagi veriKaynagi,
                          boolean sanalBrokerAdayi, double puan, String islemFikri, String aciklama,
                          double girisFiyati, double stopFiyati, double hedef1Fiyati, double hedef2Fiyati) {
        this.sembol = sembol;
        this.karar = karar;
        this.risk = risk;
        this.veriKaynagi = veriKaynagi;
        this.sanalBrokerAdayi = sanalBrokerAdayi;
        this.puan = puan;
        this.islemFikri = islemFikri;
        this.aciklama = aciklama;
        this.girisFiyati = girisFiyati;
        this.stopFiyati = stopFiyati;
        this.hedef1Fiyati = hedef1Fiyati;
        this.hedef2Fiyati = hedef2Fiyati;
    }

    public static MiniKararSonuc temel(String sembol, KararEtiketi karar, RiskSeviyesi risk,
                                      String islemFikri, boolean sanalBrokerAdayi, String aciklama,
                                      double girisFiyati, double stopFiyati, double hedef1Fiyati, double hedef2Fiyati) {
        return new MiniKararSonuc(sembol, karar, risk, VeriKaynagi.TWELVE_DATA, sanalBrokerAdayi, 0,
                islemFikri, aciklama, girisFiyati, stopFiyati, hedef1Fiyati, hedef2Fiyati);
    }

    public MiniKararSonuc puanla(double yeniPuan) {
        return new MiniKararSonuc(sembol, karar, risk, veriKaynagi, sanalBrokerAdayi, yeniPuan,
                islemFikri, aciklama, girisFiyati, stopFiyati, hedef1Fiyati, hedef2Fiyati);
    }

    public MiniKararSonuc onayliAlYap() {
        return new MiniKararSonuc(sembol, KararEtiketi.ONAYLI_AL, risk, veriKaynagi, sanalBrokerAdayi, puan,
                islemFikri, aciklama + " En iyi 3 AL adayı içine girdi.", girisFiyati, stopFiyati, hedef1Fiyati, hedef2Fiyati);
    }

    public MiniKararSonuc alAdayiOlarakBirak(String neden) {
        return new MiniKararSonuc(sembol, KararEtiketi.AL_ADAYI, risk, veriKaynagi, sanalBrokerAdayi, puan,
                islemFikri, aciklama + " " + neden, girisFiyati, stopFiyati, hedef1Fiyati, hedef2Fiyati);
    }
}
