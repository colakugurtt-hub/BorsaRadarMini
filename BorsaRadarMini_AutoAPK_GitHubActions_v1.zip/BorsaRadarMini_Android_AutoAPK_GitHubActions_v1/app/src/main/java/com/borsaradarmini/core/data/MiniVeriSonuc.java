package com.borsaradarmini.core.data;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class MiniVeriSonuc {
    public final String sembol;
    public final VeriKaynagi veriKaynagi;
    public final VeriDurumu veriDurumu;
    public final List<MiniMumVerisi> mumlar;
    public final String mesaj;
    public final boolean sanalBrokerIzinli;

    public MiniVeriSonuc(String sembol, VeriKaynagi veriKaynagi, VeriDurumu veriDurumu,
                         List<MiniMumVerisi> mumlar, String mesaj, boolean sanalBrokerIzinli) {
        this.sembol = sembol;
        this.veriKaynagi = veriKaynagi;
        this.veriDurumu = veriDurumu;
        this.mumlar = mumlar == null ? new ArrayList<>() : new ArrayList<>(mumlar);
        this.mesaj = mesaj;
        this.sanalBrokerIzinli = sanalBrokerIzinli;
    }

    public boolean basariliMi() {
        return veriDurumu == VeriDurumu.BASARILI || veriDurumu == VeriDurumu.YEDEK_BASARILI;
    }

    public MiniMumVerisi sonMum() {
        if (mumlar.isEmpty()) return null;
        return mumlar.get(mumlar.size() - 1);
    }

    public List<MiniMumVerisi> mumlarOku() {
        return Collections.unmodifiableList(mumlar);
    }

    public static MiniVeriSonuc twelve(String sembol, List<MiniMumVerisi> mumlar) {
        return new MiniVeriSonuc(sembol, VeriKaynagi.TWELVE_DATA, VeriDurumu.BASARILI, mumlar, "Twelve Data başarılı", true);
    }

    public static MiniVeriSonuc yahoo(String sembol, List<MiniMumVerisi> mumlar) {
        return new MiniVeriSonuc(sembol, VeriKaynagi.YAHOO_YEDEK, VeriDurumu.YEDEK_BASARILI, mumlar, "Yahoo yedek kaynak", false);
    }

    public static MiniVeriSonuc hata(String sembol, String mesaj) {
        return new MiniVeriSonuc(sembol, VeriKaynagi.YOK, VeriDurumu.HATALI, new ArrayList<MiniMumVerisi>(), mesaj, false);
    }
}
