package com.borsaradarmini.core.radar;

public class MiniRadarOzet {
    public final int toplam;
    public final int onayliAl;
    public final int alAdayi;
    public final int izle;
    public final int bekle;
    public final int uzakDur;
    public final int veriYetersiz;

    public MiniRadarOzet(int toplam, int onayliAl, int alAdayi, int izle, int bekle, int uzakDur, int veriYetersiz) {
        this.toplam = toplam;
        this.onayliAl = onayliAl;
        this.alAdayi = alAdayi;
        this.izle = izle;
        this.bekle = bekle;
        this.uzakDur = uzakDur;
        this.veriYetersiz = veriYetersiz;
    }

    public String sadeMetin() {
        return sadeMetin("BIST30");
    }

    public String sadeMetin(String evrenAdi) {
        if (evrenAdi == null || evrenAdi.trim().isEmpty()) evrenAdi = "BIST30";
        return "Bugünkü durum: Piyasa temkinli.\n\n"
                + evrenAdi + " içinde " + onayliAl + " hisse ONAYLI AL, "
                + alAdayi + " hisse AL adayı, " + izle + " hisse izlenebilir, "
                + bekle + " hisse bekle, " + uzakDur + " hisse uzak dur, "
                + veriYetersiz + " hisse veri yetersiz.";
    }

    public String kisaMetin() {
        return "ONAYLI " + onayliAl + " | ADAY " + alAdayi + " | İZLE " + izle
                + " | BEKLE " + bekle + " | UZAK " + uzakDur + " | VERİ " + veriYetersiz;
    }
}
