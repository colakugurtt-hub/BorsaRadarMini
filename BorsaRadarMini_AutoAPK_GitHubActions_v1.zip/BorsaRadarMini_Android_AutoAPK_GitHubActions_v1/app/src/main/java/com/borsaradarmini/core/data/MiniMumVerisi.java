package com.borsaradarmini.core.data;

public class MiniMumVerisi {
    public final double open;
    public final double high;
    public final double low;
    public final double close;
    public final long volume;

    public MiniMumVerisi(double open, double high, double low, double close, long volume) {
        this.open = open;
        this.high = high;
        this.low = low;
        this.close = close;
        this.volume = volume;
    }

    public boolean gecerliMi() {
        return open > 0 && high > 0 && low > 0 && close > 0 && high >= low && high >= open && high >= close && low <= open && low <= close && volume > 0;
    }
}
