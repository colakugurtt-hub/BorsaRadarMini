package com.borsaradarmini.core.broker;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;

public class MiniSanalBroker {
    public final double baslangicBakiye = 100000.0;
    public double bakiye = 100000.0;

    public final List<BekleyenSinyal> bekleyenler = new ArrayList<>();
    public final List<BrokerPozisyon> aciklar = new ArrayList<>();
    public final List<BrokerPozisyon> kapananlar = new ArrayList<>();
    public final List<BekleyenSinyal> iptaller = new ArrayList<>();

    private final double islemRiskOrani = 0.005; // %0,50 risk

    public void bekleyenleriTemizle() {
        Iterator<BekleyenSinyal> it = bekleyenler.iterator();
        while (it.hasNext()) {
            BekleyenSinyal s = it.next();
            if (s.durum == BekleyenSinyalDurumu.ON_BES_DK_BEKLIYOR) it.remove();
        }
    }

    public void bekleyenSinyalEkle(BekleyenSinyal s) {
        if (s == null) return;
        if (!bekleyenVarMi(s.sembol) && !acikPozisyonVarMi(s.sembol)) bekleyenler.add(s);
    }

    public boolean bekleyenVarMi(String sembol) {
        for (BekleyenSinyal s : bekleyenler) {
            if (s.sembol.equals(sembol) && s.durum == BekleyenSinyalDurumu.ON_BES_DK_BEKLIYOR) return true;
        }
        return false;
    }

    public boolean acikPozisyonVarMi(String sembol) {
        for (BrokerPozisyon p : aciklar) {
            if (p.sembol.equals(sembol) && p.durum == PozisyonDurumu.ACIK) return true;
        }
        return false;
    }

    public int aktifBekleyenSayisi() {
        int c = 0;
        for (BekleyenSinyal s : bekleyenler) if (s.durum == BekleyenSinyalDurumu.ON_BES_DK_BEKLIYOR) c++;
        return c;
    }

    public String bekleyenleriOnaylaVePozisyonAc() {
        int acilan = 0;
        int iptal = 0;
        Iterator<BekleyenSinyal> it = bekleyenler.iterator();

        while (it.hasNext()) {
            BekleyenSinyal s = it.next();
            if (s.durum != BekleyenSinyalDurumu.ON_BES_DK_BEKLIYOR) continue;

            String red = acilabilirMi(s);
            if (!red.isEmpty()) {
                s.durum = BekleyenSinyalDurumu.IPTAL_EDILDI;
                s.redSebebi = red;
                iptaller.add(s);
                it.remove();
                iptal++;
                continue;
            }

            s.kontrolFiyati = yuvarla(s.ilkSinyalFiyati * 1.005);
            s.kontrolKaniti = "Test modu: 15 dk bekleme simüle edildi. Gerçek zamanlı bekleme değildir.";

            double giris = s.kontrolFiyati;
            double riskBirim = Math.abs(giris - s.stop);
            double riskButcesi = bakiye * islemRiskOrani;
            int adet = riskBirim <= 0 ? 0 : (int)Math.floor(riskButcesi / riskBirim);
            double rr = riskBirim <= 0 ? 0.0 : (s.hedef1 - giris) / riskBirim;
            double riskYuzde = giris <= 0 ? 0.0 : (riskBirim / giris) * 100.0;

            if (adet <= 0) {
                s.durum = BekleyenSinyalDurumu.IPTAL_EDILDI;
                s.redSebebi = "Adet 0 çıktı; işlem açılmadı.";
                iptaller.add(s);
                it.remove();
                iptal++;
                continue;
            }

            if (rr < 1.5) {
                s.durum = BekleyenSinyalDurumu.IPTAL_EDILDI;
                s.redSebebi = "R/R 1.5 altında; işlem açılmadı. R/R=" + fmt(rr);
                iptaller.add(s);
                it.remove();
                iptal++;
                continue;
            }

            BrokerPozisyon p = new BrokerPozisyon(
                    s.sembol, s.ilkSinyalFiyati, s.kontrolFiyati, giris,
                    s.stop, s.hedef1, s.hedef2, adet, zaman(), riskYuzde, rr
            );

            aciklar.add(p);
            s.durum = BekleyenSinyalDurumu.BROKERE_AKTARILDI;
            it.remove();
            acilan++;
        }

        return acilan + " pozisyon açıldı, " + iptal + " sinyal iptal edildi.";
    }

    private String acilabilirMi(BekleyenSinyal s) {
        if (s == null) return "Sinyal boş.";
        if (acikPozisyonVarMi(s.sembol)) return "Aynı hissede açık pozisyon var.";
        if (aciklar.size() >= 3) return "Maksimum 3 açık pozisyon limiti dolu.";
        if (s.giris <= 0 || s.stop <= 0 || s.hedef1 <= 0) return "Fiyat alanı hatalı.";
        if (!(s.stop < s.giris && s.giris < s.hedef1)) return "AL yön matematiği hatalı.";
        return "";
    }

    public String demoFiyatGuncelle() {
        return hedef1Kapat();
    }

    public String hedef1Kapat() {
        int kapanan = 0;
        List<BrokerPozisyon> kapat = new ArrayList<>(aciklar);
        for (BrokerPozisyon p : kapat) {
            p.kapat(p.hedef1, PozisyonDurumu.HEDEF_1_GELDI, "Hedef 1 ile kapandı", zaman());
            bakiye = yuvarla(bakiye + p.netKarZarar);
            aciklar.remove(p);
            kapananlar.add(p);
            kapanan++;
        }
        return kapanan + " pozisyon hedef 1 ile kapandı.";
    }

    public String stopKapat() {
        int kapanan = 0;
        List<BrokerPozisyon> kapat = new ArrayList<>(aciklar);
        for (BrokerPozisyon p : kapat) {
            p.kapat(p.stop, PozisyonDurumu.STOP_OLDU, "Stop ile kapandı", zaman());
            bakiye = yuvarla(bakiye + p.netKarZarar);
            aciklar.remove(p);
            kapananlar.add(p);
            kapanan++;
        }
        return kapanan + " pozisyon stop ile kapandı.";
    }

    public int toplamIslemSayisi() {
        return aciklar.size() + kapananlar.size();
    }

    public int kazananSayisi() {
        int c = 0;
        for (BrokerPozisyon p : kapananlar) if (p.netKarZarar > 0) c++;
        return c;
    }

    public int kaybedenSayisi() {
        int c = 0;
        for (BrokerPozisyon p : kapananlar) if (p.netKarZarar < 0) c++;
        return c;
    }

    public double netKarZarar() {
        return yuvarla(bakiye - baslangicBakiye);
    }

    public double netKarZararYuzde() {
        return baslangicBakiye <= 0 ? 0.0 : yuvarla((netKarZarar() / baslangicBakiye) * 100.0);
    }

    public double basariOrani() {
        int kapanan = kapananlar.size();
        if (kapanan == 0) return 0.0;
        return yuvarla((kazananSayisi() * 100.0) / kapanan);
    }

    public double ortalamaKazanc() {
        double sum = 0; int c = 0;
        for (BrokerPozisyon p : kapananlar) if (p.netKarZarar > 0) { sum += p.netKarZarar; c++; }
        return c == 0 ? 0.0 : yuvarla(sum / c);
    }

    public double ortalamaKayip() {
        double sum = 0; int c = 0;
        for (BrokerPozisyon p : kapananlar) if (p.netKarZarar < 0) { sum += p.netKarZarar; c++; }
        return c == 0 ? 0.0 : yuvarla(sum / c);
    }

    public String enIyiIslem() {
        if (kapananlar.isEmpty()) return "-";
        BrokerPozisyon best = kapananlar.get(0);
        for (BrokerPozisyon p : kapananlar) if (p.netKarZarar > best.netKarZarar) best = p;
        return best.sembol + " " + fmt(best.netKarZarar) + " TL";
    }

    public String enKotuIslem() {
        if (kapananlar.isEmpty()) return "-";
        BrokerPozisyon worst = kapananlar.get(0);
        for (BrokerPozisyon p : kapananlar) if (p.netKarZarar < worst.netKarZarar) worst = p;
        return worst.sembol + " " + fmt(worst.netKarZarar) + " TL";
    }

    public String performansOzeti() {
        return "Başlangıç Bakiye: " + fmt(baslangicBakiye) + " TL\n"
                + "Güncel Bakiye: " + fmt(bakiye) + " TL\n"
                + "Net K/Z: " + fmt(netKarZarar()) + " TL (%" + fmt(netKarZararYuzde()) + ")\n"
                + "Toplam İşlem: " + toplamIslemSayisi() + "\n"
                + "Açık İşlem: " + aciklar.size() + "\n"
                + "Kapanan İşlem: " + kapananlar.size() + "\n"
                + "Kazanan: " + kazananSayisi() + "\n"
                + "Kaybeden: " + kaybedenSayisi() + "\n"
                + "Başarı Oranı: %" + fmt(basariOrani()) + "\n"
                + "Ortalama Kazanç: " + fmt(ortalamaKazanc()) + " TL\n"
                + "Ortalama Kayıp: " + fmt(ortalamaKayip()) + " TL\n"
                + "En İyi İşlem: " + enIyiIslem() + "\n"
                + "En Kötü İşlem: " + enKotuIslem();
    }

    private double simuleKontrolFiyati(BekleyenSinyal s) {
        return yuvarla(s.ilkSinyalFiyati * 1.005);
    }

    private String zaman() {
        return new SimpleDateFormat("dd.MM.yyyy HH:mm:ss", Locale.getDefault()).format(new Date());
    }

    private String fmt(double v) {
        return String.format(Locale.US, "%.2f", v);
    }

    private double yuvarla(double v) {
        return Math.round(v * 100.0) / 100.0;
    }
}
