package com.borsaradarmini.core.broker;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class MiniSanalBroker {
    public double bakiye = 100000.0;
    public final List<BekleyenSinyal> bekleyenler = new ArrayList<>();
    public final List<BrokerPozisyon> aciklar = new ArrayList<>();
    public final List<BrokerPozisyon> kapananlar = new ArrayList<>();

    public void bekleyenSinyalEkle(BekleyenSinyal sinyal) {
        if (sinyal == null) return;
        if (ayniSembolVarMi(sinyal.sembol)) return;
        bekleyenler.add(sinyal);
    }

    public boolean bekleyenVarMi(String sembol) {
        for (BekleyenSinyal s : bekleyenler) {
            if (s.sembol.equals(sembol) && s.durum == BekleyenSinyalDurumu.ON_BES_DK_BEKLIYOR) return true;
        }
        return false;
    }

    public boolean ayniSembolVarMi(String sembol) {
        for (BekleyenSinyal s : bekleyenler) if (s.sembol.equals(sembol)) return true;
        for (BrokerPozisyon p : aciklar) if (p.sembol.equals(sembol)) return true;
        return false;
    }

    public String bekleyenleriOnaylaVePozisyonAc() {
        int kalanSlot = Math.max(0, 3 - aciklar.size());
        if (kalanSlot <= 0) return "Maksimum açık işlem limiti dolu.";

        int acilan = 0;
        Iterator<BekleyenSinyal> it = bekleyenler.iterator();
        while (it.hasNext() && kalanSlot > 0) {
            BekleyenSinyal s = it.next();
            if (s.durum == BekleyenSinyalDurumu.ON_BES_DK_BEKLIYOR) {
                BrokerPozisyon p = new BrokerPozisyon(s.sembol, s.giris, s.stop, s.hedef1, s.hedef2, 10000.0);
                aciklar.add(p);
                s.durum = BekleyenSinyalDurumu.BROKERE_AKTARILDI;
                it.remove();
                acilan++;
                kalanSlot--;
            }
        }

        if (acilan == 0) return "Açılacak bekleyen aktif sinyal yok.";
        return acilan + " sanal pozisyon açıldı.";
    }

    public String demoFiyatGuncelle() {
        if (aciklar.isEmpty()) return "Açık pozisyon yok.";

        List<BrokerPozisyon> kapanacak = new ArrayList<>(aciklar);
        for (BrokerPozisyon p : kapanacak) {
            p.durum = BrokerPozisyonDurumu.HEDEF_1_GELDI;
            double adet = p.tutar / p.giris;
            p.netKarZarar = (p.hedef1 - p.giris) * adet;
            bakiye += p.netKarZarar;
            kapananlar.add(p);
            aciklar.remove(p);
        }
        return kapanacak.size() + " pozisyon Hedef 1 ile kapandı.";
    }
}
