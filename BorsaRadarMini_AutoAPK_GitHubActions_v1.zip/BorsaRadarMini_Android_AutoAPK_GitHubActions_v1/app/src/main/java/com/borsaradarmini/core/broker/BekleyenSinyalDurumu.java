package com.borsaradarmini.core.broker;

public enum BekleyenSinyalDurumu {
    ON_BES_DK_BEKLIYOR,
    ONAYLANDI,
    IPTAL_EDILDI,
    BROKERE_AKTARILDI
}
