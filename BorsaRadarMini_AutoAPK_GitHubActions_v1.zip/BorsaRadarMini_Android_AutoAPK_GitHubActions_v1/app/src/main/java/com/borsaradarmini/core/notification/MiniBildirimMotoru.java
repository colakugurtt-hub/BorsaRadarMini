package com.borsaradarmini.core.notification;

public class MiniBildirimMotoru {
    public String onayliAlMetni(String sembol, double giris, double stop, double hedef1, double hedef2) {
        return "Borsa Radar Mini — ONAYLI AL Adayı\n\n" +
                sembol + " için ONAYLI AL adayı oluştu.\n" +
                "Giriş: " + fmt(giris) + "\n" +
                "Stop: " + fmt(stop) + "\n" +
                "Hedef 1: " + fmt(hedef1) + "\n" +
                "Hedef 2: " + fmt(hedef2) + "\n\n" +
                "Sistem bu sinyali hemen işleme çevirmeyecek. 15 dakika sonra tekrar kontrol edecek.\n\n" +
                "Bu bildirim yatırım tavsiyesi değildir; kişisel sanal takip içindir.";
    }

    public String whatsappManuelMetin(String sembol) {
        return "Borsa Radar Mini: " + sembol + " için ONAYLI AL adayı oluştu. Bu otomatik WhatsApp gönderimi değildir; manuel paylaşım metnidir.";
    }

    private String fmt(double v) {
        return String.format(java.util.Locale.US, "%.2f", v);
    }
}
