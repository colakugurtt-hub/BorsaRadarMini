package com.borsaradarmini.core.broker;

public enum PozisyonDurumu {
    ACIK,
    HEDEF_1_GELDI,
    HEDEF_2_GELDI,
    STOP_OLDU,
    SAT_ILE_KAPANDI
}
