package com.borsaradarmini.core.data;

public enum VeriDurumu {
    BASARILI,
    YEDEK_BASARILI,
    HATALI,
    VERI_YOK,
    KALITE_RED
}
