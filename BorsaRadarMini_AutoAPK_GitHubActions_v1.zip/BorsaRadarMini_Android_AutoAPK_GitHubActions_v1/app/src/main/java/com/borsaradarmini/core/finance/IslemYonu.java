package com.borsaradarmini.core.finance;

public enum IslemYonu {
    AL,
    SAT_KAPAT,
    SHORT
}
