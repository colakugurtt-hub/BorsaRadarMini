package com.borsaradarmini.core.finance;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class MiniFinansSonuc {
    public final boolean gecerliMi;
    public final List<RedSebebi> redSebepleri;
    public final int adet;
    public final double kullanilanSermaye;
    public final double riskYuzdesi;
    public final double hedef1GetiriYuzdesi;
    public final double hedef2GetiriYuzdesi;
    public final double hedef1RiskOdul;
    public final double hedef2RiskOdul;
    public final double girisKomisyonu;
    public final double hedef1NetKar;
    public final double hedef2NetKar;
    public final double stopNetZarar;
    public final String ozetMetin;

    public MiniFinansSonuc(boolean gecerliMi, List<RedSebebi> redSebepleri, int adet, double kullanilanSermaye,
                           double riskYuzdesi, double hedef1GetiriYuzdesi, double hedef2GetiriYuzdesi,
                           double hedef1RiskOdul, double hedef2RiskOdul, double girisKomisyonu,
                           double hedef1NetKar, double hedef2NetKar, double stopNetZarar, String ozetMetin) {
        this.gecerliMi = gecerliMi;
        this.redSebepleri = redSebepleri == null ? new ArrayList<>() : new ArrayList<>(redSebepleri);
        this.adet = adet;
        this.kullanilanSermaye = kullanilanSermaye;
        this.riskYuzdesi = riskYuzdesi;
        this.hedef1GetiriYuzdesi = hedef1GetiriYuzdesi;
        this.hedef2GetiriYuzdesi = hedef2GetiriYuzdesi;
        this.hedef1RiskOdul = hedef1RiskOdul;
        this.hedef2RiskOdul = hedef2RiskOdul;
        this.girisKomisyonu = girisKomisyonu;
        this.hedef1NetKar = hedef1NetKar;
        this.hedef2NetKar = hedef2NetKar;
        this.stopNetZarar = stopNetZarar;
        this.ozetMetin = ozetMetin;
    }

    public List<RedSebebi> redSebepleriOku() {
        return Collections.unmodifiableList(redSebepleri);
    }
}
