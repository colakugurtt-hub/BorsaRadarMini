package com.borsaradarmini.core.broker;

public class BrokerPozisyon {
    public final String id;
    public final String sembol;
    public final double ilkSinyalFiyati;
    public final double kontrolFiyati;
    public final double giris;
    public final double stop;
    public final double hedef1;
    public final double hedef2;
    public final int adet;
    public final double kullanilanSermaye;
    public final double riskTl;
    public final double riskYuzdesi;
    public final double hedef1RiskOdul;
    public final String acilisZamani;

    public double guncelFiyat;
    public double cikisFiyati;
    public String kapanisZamani;
    public PozisyonDurumu durum;
    public double netKarZarar;
    public double netKarZararYuzde;
    public String kapanisSebebi;

    public BrokerPozisyon(String sembol, double giris, double stop, double hedef1, double hedef2, int adet) {
        this(sembol, giris, giris, giris, stop, hedef1, hedef2, adet, "", 0.0, 0.0);
    }

    public BrokerPozisyon(String sembol, double ilkSinyalFiyati, double kontrolFiyati, double giris,
                          double stop, double hedef1, double hedef2, int adet,
                          String acilisZamani, double riskYuzdesi, double hedef1RiskOdul) {
        this.id = sembol + "-" + System.currentTimeMillis();
        this.sembol = sembol;
        this.ilkSinyalFiyati = ilkSinyalFiyati;
        this.kontrolFiyati = kontrolFiyati;
        this.giris = giris;
        this.stop = stop;
        this.hedef1 = hedef1;
        this.hedef2 = hedef2;
        this.adet = adet;
        this.kullanilanSermaye = yuvarla(giris * adet);
        this.riskTl = yuvarla(Math.abs(giris - stop) * adet);
        this.riskYuzdesi = riskYuzdesi;
        this.hedef1RiskOdul = hedef1RiskOdul;
        this.acilisZamani = acilisZamani == null ? "" : acilisZamani;
        this.guncelFiyat = giris;
        this.cikisFiyati = 0.0;
        this.kapanisZamani = "";
        this.durum = PozisyonDurumu.ACIK;
        this.netKarZarar = 0.0;
        this.netKarZararYuzde = 0.0;
        this.kapanisSebebi = "";
    }

    public double anlikKarZararTl() {
        return yuvarla((guncelFiyat - giris) * adet);
    }

    public double anlikKarZararYuzde() {
        if (giris <= 0) return 0.0;
        return yuvarla(((guncelFiyat - giris) / giris) * 100.0);
    }

    public void kapat(double fiyat, PozisyonDurumu yeniDurum, String sebep, String zaman) {
        this.cikisFiyati = fiyat;
        this.guncelFiyat = fiyat;
        this.durum = yeniDurum;
        this.kapanisSebebi = sebep == null ? "" : sebep;
        this.kapanisZamani = zaman == null ? "" : zaman;
        this.netKarZarar = yuvarla((fiyat - giris) * adet);
        this.netKarZararYuzde = anlikKarZararYuzde();
    }

    private double yuvarla(double v) {
        return Math.round(v * 100.0) / 100.0;
    }
}
