package com.borsaradarmini;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.content.SharedPreferences;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import android.text.InputType;
import android.graphics.drawable.GradientDrawable;
import android.text.Layout;

import com.borsaradarmini.core.radar.*;
import com.borsaradarmini.core.decision.*;
import com.borsaradarmini.core.broker.*;
import com.borsaradarmini.core.notification.*;
import com.borsaradarmini.core.util.MiniFormat;

import java.util.List;

public class MainActivity extends Activity {
    private LinearLayout root;
    private LinearLayout content;
    private SharedPreferences prefs;
    private MiniRadarSonuc sonRadar;
    private MiniKararSonuc tekHisseSonuc = null;
    private MiniSanalBroker broker = new MiniSanalBroker();
    private MiniBildirimMotoru bildirim = new MiniBildirimMotoru();
    private String seciliSembol = "BIMAS";
    private BistEvreni aktifEvren = BistEvreni.BIST30;
    private final BistSembolListesi sembolListesi = new BistSembolListesi();
    private boolean canliTwelveData = false;
    private boolean taramaDevamEdiyor = false;

    private final int BG = Color.rgb(245, 247, 250);
    private final int CARD = Color.WHITE;
    private final int TEXT = Color.rgb(20, 28, 38);
    private final int MUTED = Color.rgb(95, 108, 125);
    private final int BLUE = Color.rgb(31, 111, 235);
    private final int GREEN = Color.rgb(28, 135, 85);
    private final int RED = Color.rgb(185, 28, 28);
    private final int AMBER = Color.rgb(180, 105, 0);
    private final int GRAY = Color.rgb(125, 135, 150);

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences("borsa_radar_mini_v2", MODE_PRIVATE);
        sonRadar = new MiniBist30Radar().taraDemo(aktifEvren);
        bekleyenleriYenidenKur();
        buildShell();
        showAnaRadar();
    }

    private void bekleyenleriYenidenKur() {
        if (sonRadar == null) return;
        broker.bekleyenleriTemizle();
        if (!canliTwelveData) return;
        for (MiniKararSonuc k : sonRadar.kararlarOku()) {
            if (k.karar == KararEtiketi.ONAYLI_AL) {
                broker.bekleyenSinyalEkle(new BekleyenSinyal(k));
            }
        }
    }

    private void buildShell() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);

        TextView header = text("Borsa Radar Mini v2", 22, true, TEXT);
        header.setPadding(dp(16), dp(18), dp(16), dp(4));
        root.addView(header);

        TextView sub = text("Kişisel BIST30/BIST50 radar + sanal broker merkezi", 13, false, MUTED);
        sub.setPadding(dp(16), 0, dp(16), dp(10));
        root.addView(sub);

        LinearLayout tabs = new LinearLayout(this);
        tabs.setOrientation(LinearLayout.HORIZONTAL);
        tabs.setPadding(dp(8), dp(4), dp(8), dp(8));
        root.addView(tabs);

        tabs.addView(tabButton("Radar", () -> showAnaRadar()));
        tabs.addView(tabButton("Detay", () -> showHisseDetay(seciliSembol)));
        tabs.addView(tabButton("Broker", () -> showSanalBroker()));
        tabs.addView(tabButton("Ayar", () -> showAyarlar()));

        ScrollView scroll = new ScrollView(this);
        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(12), dp(6), dp(12), dp(20));
        scroll.addView(content);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(root);
    }

    private TextView tabButton(String label, final Runnable action) {
        TextView b = text(label, 13, true, Color.WHITE);
        b.setGravity(Gravity.CENTER);
        b.setPadding(dp(8), dp(10), dp(8), dp(10));
        b.setBackground(round(BLUE, 14));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1);
        lp.setMargins(dp(4), 0, dp(4), 0);
        b.setLayoutParams(lp);
        b.setOnClickListener(v -> action.run());
        return b;
    }

    private void showAnaRadar() {
        content.removeAllViews();
        String evrenAd = sembolListesi.ad(aktifEvren);

        content.addView(sectionTitle("Radar Paneli"));
        content.addView(evrenSecimKart());
        content.addView(anaOzetKart(evrenAd));

        TextView canli = actionButton(taramaDevamEdiyor ? "Taranıyor..." : "Twelve Data ile " + evrenAd + " Tara", taramaDevamEdiyor ? GRAY : GREEN);
        canli.setEnabled(!taramaDevamEdiyor);
        canli.setOnClickListener(v -> twelveDataTara());
        content.addView(canli);

        content.addView(tekHisseTestKart());

        if (tekHisseSonuc != null) {
            content.addView(tekHisseSonucKart(tekHisseSonuc));
        }

        TextView demo = actionButton("Demo veriye dön", BLUE);
        demo.setOnClickListener(v -> {
            sonRadar = new MiniBist30Radar().taraDemo(aktifEvren);
            tekHisseSonuc = null;
            canliTwelveData = false;
            bekleyenleriYenidenKur();
            showAnaRadar();
        });
        content.addView(demo);

        content.addView(sectionTitle("Radar sonuçları"));
        content.addView(small("Ana liste korunur. Tek hisse testi ayrı sonuç kartında gösterilir."));

        for (MiniKararSonuc k : sonRadar.kararlarOku()) {
            content.addView(radarCard(k));
        }
    }

    private LinearLayout anaOzetKart(String evrenAd) {
        String kaynak = canliTwelveData
                ? "Veri kaynağı: Twelve Data / XIST / 1 gün\nEvren: " + evrenAd + " / " + sembolListesi.adet(aktifEvren) + " hisse"
                : "Veri kaynağı: Demo test verisi\nEvren: " + evrenAd + " / " + sembolListesi.adet(aktifEvren) + " hisse";

        LinearLayout box = card();
        box.addView(text("Bugünkü durum", 17, true, TEXT));
        box.addView(small(sonRadar.ozet.sadeMetin(evrenAd)));
        box.addView(small(kaynak));
        box.addView(small("Kısa özet: " + sonRadar.ozet.kisaMetin()));
        return box;
    }

    private LinearLayout evrenSecimKart() {
        LinearLayout box = card();
        box.addView(text("Piyasa evreni", 17, true, TEXT));
        box.addView(small("Grow 55 için BIST30 güvenli, BIST50 sınırda ama kullanılabilir. BIST100 şu an kapalı."));

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setPadding(0, dp(8), 0, 0);

        TextView b30 = miniButton("BIST30", aktifEvren == BistEvreni.BIST30 ? GREEN : BLUE);
        b30.setOnClickListener(v -> evrenDegistir(BistEvreni.BIST30));
        row.addView(b30);

        TextView b50 = miniButton("BIST50", aktifEvren == BistEvreni.BIST50 ? GREEN : BLUE);
        b50.setOnClickListener(v -> evrenDegistir(BistEvreni.BIST50));
        row.addView(b50);

        box.addView(row);
        return box;
    }

    private void evrenDegistir(BistEvreni yeniEvren) {
        aktifEvren = yeniEvren == null ? BistEvreni.BIST30 : yeniEvren;
        List<String> semboller = sembolListesi.getir(aktifEvren);
        if (!semboller.contains(seciliSembol)) seciliSembol = semboller.get(0);
        sonRadar = new MiniBist30Radar().taraDemo(aktifEvren);
        tekHisseSonuc = null;
        canliTwelveData = false;
        bekleyenleriYenidenKur();
        showAnaRadar();
    }

    private LinearLayout tekHisseTestKart() {
        LinearLayout box = card();
        box.addView(text("Tek hisse test merkezi", 17, true, TEXT));
        box.addView(small("Seçtiğin hisse tek başına Twelve Data ile test edilir. Ana radar listesi bozulmaz."));

        final List<String> semboller = sembolListesi.getir(aktifEvren);
        Spinner spinner = new Spinner(this);
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, semboller);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);

        int idx = semboller.indexOf(seciliSembol);
        if (idx < 0) idx = 0;
        spinner.setSelection(idx);
        spinner.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(android.widget.AdapterView<?> parent, View view, int position, long id) {
                if (position >= 0 && position < semboller.size()) seciliSembol = semboller.get(position);
            }

            @Override
            public void onNothingSelected(android.widget.AdapterView<?> parent) { }
        });
        box.addView(spinner);

        TextView test = actionButton(taramaDevamEdiyor ? "Taranıyor..." : "Seçili hisseyi test et: " + seciliSembol, taramaDevamEdiyor ? GRAY : AMBER);
        test.setEnabled(!taramaDevamEdiyor);
        test.setOnClickListener(v -> tekSembolTest(seciliSembol));
        box.addView(test);

        return box;
    }

    private LinearLayout tekHisseSonucKart(final MiniKararSonuc k) {
        LinearLayout box = card();
        box.addView(text("Tek hisse sonucu: " + k.sembol, 17, true, TEXT));
        box.addView(line("Karar", k.karar.name().replace("_", " ")));
        box.addView(line("Risk", k.risk.name()));
        box.addView(line("Puan", String.format(java.util.Locale.US, "%.1f", k.puan)));
        box.addView(line("Giriş", MiniFormat.fiyat(k.girisFiyati)));
        box.addView(line("Stop", MiniFormat.fiyat(k.stopFiyati)));
        box.addView(line("Hedef 1", MiniFormat.fiyat(k.hedef1Fiyati)));
        box.addView(small(k.aciklama));
        box.setOnClickListener(v -> {
            seciliSembol = k.sembol;
            showHisseDetay(k.sembol);
        });
        return box;
    }

    private TextView miniButton(String label, int color) {
        TextView b = text(label, 14, true, Color.WHITE);
        b.setGravity(Gravity.CENTER);
        b.setPadding(dp(8), dp(9), dp(8), dp(9));
        b.setBackground(round(color, 12));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1);
        lp.setMargins(dp(3), 0, dp(3), 0);
        b.setLayoutParams(lp);
        return b;
    }

    private void twelveDataTara() {
        final String apiKey = prefs.getString("twelve_api_key", "").trim();
        if (apiKey.isEmpty()) {
            Toast.makeText(this, "Önce Ayar ekranından Twelve Data API key kaydet.", Toast.LENGTH_LONG).show();
            showAyarlar();
            return;
        }
        if (taramaDevamEdiyor) return;
        taramaDevamEdiyor = true;
        showAnaRadar();
        new Thread(() -> {
            MiniRadarSonuc sonuc = new MiniBist30Radar().taraTwelveData(apiKey, aktifEvren);
            runOnUiThread(() -> {
                sonRadar = sonuc;
                tekHisseSonuc = null;
                canliTwelveData = true;
                taramaDevamEdiyor = false;
                bekleyenleriYenidenKur();
                Toast.makeText(this, "Twelve Data taraması bitti.", Toast.LENGTH_SHORT).show();
                showAnaRadar();
            });
        }).start();
    }

    private LinearLayout radarCard(final MiniKararSonuc k) {
        LinearLayout box = card();
        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);

        TextView left = text(k.sembol, 19, true, TEXT);
        top.addView(left, new LinearLayout.LayoutParams(0, -2, 1));

        TextView badge = text(k.karar.name().replace("_", " "), 12, true, Color.WHITE);
        badge.setGravity(Gravity.CENTER);
        badge.setPadding(dp(8), dp(5), dp(8), dp(5));
        badge.setBackground(round(colorForKarar(k.karar), 20));
        top.addView(badge);
        box.addView(top);

        String brokerDurumu = broker.bekleyenVarMi(k.sembol) ? "15 dk onay bekliyor" : (k.sanalBrokerAdayi ? "Aday" : "Açılmaz");
        box.addView(small("Puan: " + String.format(java.util.Locale.US, "%.1f", k.puan)
                + "   |   Risk: " + k.risk.name()
                + "   |   Broker: " + brokerDurumu));
        box.addView(small(k.islemFikri + " — " + k.aciklama));

        box.setOnClickListener(v -> {
            seciliSembol = k.sembol;
            showHisseDetay(k.sembol);
        });
        return box;
    }

    private void tekSembolTest(final String sembol) {
        final String apiKey = prefs.getString("twelve_api_key", "").trim();
        if (apiKey.isEmpty()) {
            Toast.makeText(this, "Önce Ayar ekranından Twelve Data API key kaydet.", Toast.LENGTH_LONG).show();
            showAyarlar();
            return;
        }
        if (taramaDevamEdiyor) return;
        taramaDevamEdiyor = true;
        showAnaRadar();
        new Thread(() -> {
            MiniRadarSonuc sonuc = new MiniBist30Radar().tekSembolTwelveDataTest(sembol, apiKey);
            runOnUiThread(() -> {
                if (sonuc != null && !sonuc.kararlarOku().isEmpty()) {
                    tekHisseSonuc = sonuc.kararlarOku().get(0);
                }
                taramaDevamEdiyor = false;
                Toast.makeText(this, sembol + " tek hisse testi bitti.", Toast.LENGTH_SHORT).show();
                showAnaRadar();
            });
        }).start();
    }

    private void showHisseDetay(String sembol) {
        content.removeAllViews();
        seciliSembol = sembol;
        MiniKararSonuc k = kararBul(sembol);

        content.addView(sectionTitle("Hisse Detay"));
        if (k == null) {
            content.addView(infoCard("Hisse: " + sembol, "Karar bulunamadı."));
            return;
        }

        content.addView(infoCard("Hisse: " + k.sembol,
                "Karar: " + k.karar.name().replace("_", " ") + "\n" +
                "Risk: " + k.risk.name() + "\n" +
                "Puan: " + String.format(java.util.Locale.US, "%.1f", k.puan) + "\n" +
                "Giriş: " + MiniFormat.fiyat(k.girisFiyati) + "\n" +
                "Stop: " + MiniFormat.fiyat(k.stopFiyati) + "\n" +
                "Hedef 1: " + MiniFormat.fiyat(k.hedef1Fiyati) + "\n" +
                "Hedef 2: " + MiniFormat.fiyat(k.hedef2Fiyati) + "\n" +
                "Program yorumu: " + k.aciklama));

        if (k.karar == KararEtiketi.ONAYLI_AL) {
            content.addView(infoCard("Bildirim metni", bildirim.onayliAlMetni(k.sembol, k.girisFiyati, k.stopFiyati, k.hedef1Fiyati, k.hedef2Fiyati)));
        }
    }


    private void showSanalBroker() {
        content.removeAllViews();
        content.addView(sectionTitle("Sanal Broker"));

        content.addView(infoCard("Performans Karnesi", broker.performansOzeti()));

        content.addView(infoCard("Durum Özeti",
                "Aktif Bekleyen Sinyal: " + broker.aktifBekleyenSayisi() + "\n" +
                "Açık İşlem: " + broker.aciklar.size() + "\n" +
                "Kapanan İşlem: " + broker.kapananlar.size() + "\n" +
                "İptal Edilen Sinyal: " + broker.iptaller.size()));

        boolean bekleyenAktif = broker.aktifBekleyenSayisi() > 0;
        TextView onayla = actionButton(bekleyenAktif ? "Bekleyen sinyalleri sanal pozisyona aktar" : "Bekleyen aktif sinyal yok", bekleyenAktif ? GREEN : GRAY);
        onayla.setEnabled(bekleyenAktif);
        onayla.setOnClickListener(v -> {
            Toast.makeText(this, broker.bekleyenleriOnaylaVePozisyonAc(), Toast.LENGTH_SHORT).show();
            showSanalBroker();
        });
        content.addView(onayla);

        boolean acikVar = !broker.aciklar.isEmpty();
        TextView hedef = actionButton(acikVar ? "Açık işlemleri Hedef 1 ile kapat" : "Açık pozisyon yok", acikVar ? BLUE : GRAY);
        hedef.setEnabled(acikVar);
        hedef.setOnClickListener(v -> {
            Toast.makeText(this, broker.hedef1Kapat(), Toast.LENGTH_SHORT).show();
            showSanalBroker();
        });
        content.addView(hedef);

        TextView stop = actionButton(acikVar ? "Açık işlemleri Stop ile kapat" : "Stop için açık pozisyon yok", acikVar ? RED : GRAY);
        stop.setEnabled(acikVar);
        stop.setOnClickListener(v -> {
            Toast.makeText(this, broker.stopKapat(), Toast.LENGTH_SHORT).show();
            showSanalBroker();
        });
        content.addView(stop);

        if (!broker.bekleyenler.isEmpty()) {
            StringBuilder sb = new StringBuilder();
            for (BekleyenSinyal s : broker.bekleyenler) {
                sb.append(s.sembol)
                        .append(" — 15 dk kontrol bekliyor\n")
                        .append("İlk fiyat: ").append(MiniFormat.fiyat(s.ilkSinyalFiyati)).append("\n")
                        .append("Giriş: ").append(MiniFormat.fiyat(s.giris)).append(" | Stop: ").append(MiniFormat.fiyat(s.stop)).append(" | Hedef: ").append(MiniFormat.fiyat(s.hedef1)).append("\n\n");
            }
            content.addView(infoCard("Bekleyen 15 dk sinyalleri", sb.toString()));
        }

        if (!broker.aciklar.isEmpty()) {
            StringBuilder sb = new StringBuilder();
            for (BrokerPozisyon p : broker.aciklar) {
                sb.append(p.sembol).append(" — AÇIK\n")
                        .append("Açılış: ").append(p.acilisZamani).append("\n")
                        .append("İlk fiyat: ").append(MiniFormat.fiyat(p.ilkSinyalFiyati)).append(" | Kontrol: ").append(MiniFormat.fiyat(p.kontrolFiyati)).append("\n")
                        .append("Giriş: ").append(MiniFormat.fiyat(p.giris)).append(" | Güncel: ").append(MiniFormat.fiyat(p.guncelFiyat)).append("\n")
                        .append("Stop: ").append(MiniFormat.fiyat(p.stop)).append(" | Hedef 1: ").append(MiniFormat.fiyat(p.hedef1)).append("\n")
                        .append("Adet: ").append(p.adet).append(" | Risk: ").append(MiniFormat.tl(p.riskTl)).append(" | R/R: ").append(String.format(java.util.Locale.US, "%.2f", p.hedef1RiskOdul)).append("\n")
                        .append("Anlık K/Z: ").append(MiniFormat.tl(p.anlikKarZararTl())).append(" (%").append(String.format(java.util.Locale.US, "%.2f", p.anlikKarZararYuzde())).append(")\n\n");
            }
            content.addView(infoCard("Açık işlemler", sb.toString()));
        }

        if (!broker.kapananlar.isEmpty()) {
            StringBuilder sb = new StringBuilder();
            for (BrokerPozisyon p : broker.kapananlar) {
                sb.append(p.sembol).append(" — ").append(p.durum.name()).append("\n")
                        .append("Açılış: ").append(p.acilisZamani).append("\n")
                        .append("Kapanış: ").append(p.kapanisZamani).append("\n")
                        .append("Giriş: ").append(MiniFormat.fiyat(p.giris)).append(" | Çıkış: ").append(MiniFormat.fiyat(p.cikisFiyati)).append("\n")
                        .append("Adet: ").append(p.adet).append("\n")
                        .append("K/Z: ").append(MiniFormat.tl(p.netKarZarar)).append(" (%").append(String.format(java.util.Locale.US, "%.2f", p.netKarZararYuzde)).append(")\n")
                        .append("Sonuç: ").append(p.netKarZarar > 0 ? "DOĞRU" : (p.netKarZarar < 0 ? "YANLIŞ" : "NÖTR")).append("\n\n");
            }
            content.addView(infoCard("Kapanan işlemler / işlem geçmişi", sb.toString()));
        }

        if (!broker.iptaller.isEmpty()) {
            StringBuilder sb = new StringBuilder();
            for (BekleyenSinyal s : broker.iptaller) {
                sb.append(s.sembol).append(" — İPTAL\n")
                        .append("Sebep: ").append(s.redSebebi).append("\n\n");
            }
            content.addView(infoCard("İptal edilen sinyaller", sb.toString()));
        }
    }


    private void showAyarlar() {
        content.removeAllViews();
        content.addView(sectionTitle("Ayarlar"));

        LinearLayout keyCard = card();
        keyCard.addView(text("Twelve Data API Key", 18, true, TEXT));
        EditText api = new EditText(this);
        api.setSingleLine(true);
        api.setHint("API key gir");
        api.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);
        api.setText(prefs.getString("twelve_api_key", ""));
        keyCard.addView(api);

        TextView save = actionButton("API Key Kaydet", GREEN);
        save.setOnClickListener(v -> {
            prefs.edit().putString("twelve_api_key", api.getText().toString().trim()).apply();
            Toast.makeText(this, "API key kaydedildi", Toast.LENGTH_SHORT).show();
        });
        keyCard.addView(save);
        content.addView(keyCard);

        content.addView(infoCard("Piyasa evreni", "Aktif seçim: " + sembolListesi.ad(aktifEvren) + "\nBIST30: Aktif\nBIST50: Aktif / Grow 55 sınırında\nBIST100: Şimdilik kapalı"));
        content.addView(infoCard("Sanal broker ayarları", "Sanal bakiye: " + MiniFormat.tl(100000) + "\nİşlem başı sanal tutar: " + MiniFormat.tl(10000) + "\nMaksimum açık işlem: 3\nGünlük maksimum işlem: 3\nRisk modu: Temkinli"));
        content.addView(infoCard("Bildirim", "Uygulama içi bildirim: Aktif\nEmail: Metin üretilecek\nWhatsApp: Otomatik gönderim yok, manuel paylaşım metni üretilecek"));
    }

    private MiniKararSonuc kararBul(String sembol) {
        if (tekHisseSonuc != null && tekHisseSonuc.sembol.equals(sembol)) return tekHisseSonuc;
        for (MiniKararSonuc k : sonRadar.kararlarOku()) if (k.sembol.equals(sembol)) return k;
        return null;
    }

    private TextView actionButton(String label, int color) {
        TextView b = text(label, 15, true, Color.WHITE);
        b.setGravity(Gravity.CENTER);
        b.setPadding(dp(12), dp(11), dp(12), dp(11));
        b.setBackground(round(color, 14));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, 0, 0, dp(10));
        b.setLayoutParams(lp);
        return b;
    }

    private LinearLayout card() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(14), dp(12), dp(14), dp(12));
        box.setBackground(round(CARD, 18));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, 0, 0, dp(10));
        box.setLayoutParams(lp);
        return box;
    }

    private TextView sectionTitle(String s) {
        TextView t = text(s, 19, true, TEXT);
        t.setPadding(dp(4), dp(6), dp(4), dp(8));
        return t;
    }

    private LinearLayout infoCard(String title, String body) {
        LinearLayout box = card();
        box.addView(text(title, 17, true, TEXT));
        TextView b = text(body, 14, false, MUTED);
        b.setPadding(0, dp(6), 0, 0);
        box.addView(b);
        return box;
    }

    private TextView line(String k, String v) {
        TextView t = text(k + ": " + v, 14, false, TEXT);
        t.setPadding(0, dp(3), 0, 0);
        return t;
    }

    private TextView small(String s) {
        TextView t = text(s, 13, false, MUTED);
        t.setPadding(0, dp(8), 0, 0);
        return t;
    }

    private TextView text(String s, int sp, boolean bold, int color) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        t.setTextScaleX(1.0f);
        t.setLetterSpacing(0.0f);
        t.setIncludeFontPadding(true);
        t.setSingleLine(false);
        if (android.os.Build.VERSION.SDK_INT >= 23) {
            t.setHyphenationFrequency(Layout.HYPHENATION_FREQUENCY_NONE);
            t.setBreakStrategy(Layout.BREAK_STRATEGY_SIMPLE);
        }
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private GradientDrawable round(int color, int radius) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(radius));
        return g;
    }

    private int colorForKarar(KararEtiketi karar) {
        if (karar == KararEtiketi.ONAYLI_AL) return GREEN;
        if (karar == KararEtiketi.IZLE || karar == KararEtiketi.BEKLE) return AMBER;
        if (karar == KararEtiketi.VERI_YETERSIZ || karar == KararEtiketi.UZAK_DUR) return RED;
        return BLUE;
    }

    private String fmt(double v) {
        return String.format(java.util.Locale.US, "%.2f", v);
    }

    private int dp(int v) {
        return (int)(v * getResources().getDisplayMetrics().density + 0.5f);
    }
}
