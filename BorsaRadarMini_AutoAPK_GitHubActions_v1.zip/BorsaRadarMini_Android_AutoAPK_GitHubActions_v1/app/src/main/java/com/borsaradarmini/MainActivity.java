package com.borsaradarmini;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.content.SharedPreferences;
import android.view.Gravity;
import android.widget.*;
import android.text.InputType;
import android.graphics.drawable.GradientDrawable;
import android.text.Layout;

import com.borsaradarmini.core.radar.*;
import com.borsaradarmini.core.decision.*;
import com.borsaradarmini.core.broker.*;
import com.borsaradarmini.core.notification.*;
import com.borsaradarmini.core.util.MiniFormat;

import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {
    private LinearLayout root;
    private LinearLayout content;
    private SharedPreferences prefs;
    private MiniRadarSonuc sonRadar;
    private MiniSanalBroker broker = new MiniSanalBroker();
    private MiniBildirimMotoru bildirim = new MiniBildirimMotoru();
    private String seciliSembol = "BIMAS";
    private boolean canliTwelveData = false;
    private boolean taramaDevamEdiyor = false;

    private final int BG = Color.rgb(245, 247, 250);
    private final int CARD = Color.WHITE;
    private final int TEXT = Color.rgb(20, 28, 38);
    private final int MUTED = Color.rgb(95, 108, 125);
    private final int BLUE = Color.rgb(31, 111, 235);
    private final int GREEN = Color.rgb(28, 135, 85);
    private final int RED = Color.rgb(185, 28, 28);
    private final int AMBER = Color.rgb(180, 105, 0);
    private final int GRAY = Color.rgb(125, 135, 150);
    private final int TEAL = Color.rgb(0, 145, 130);

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences("borsa_radar_mini_v2", MODE_PRIVATE);
        sonRadar = new MiniBist30Radar().taraDemo();
        bekleyenleriYenidenKur();
        buildShell();
        showAnaRadar();
    }


    private void bekleyenleriYenidenKur() {
        broker = new MiniSanalBroker();
        if (sonRadar == null) return;
        for (MiniKararSonuc k : sonRadar.kararlarOku()) {
            if (k.karar == KararEtiketi.ONAYLI_AL) {
                broker.bekleyenSinyalEkle(new BekleyenSinyal(k));
            }
        }
    }

    private void buildShell() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);

        TextView header = text("Borsa Radar Mini v2", 22, true, TEXT);
        header.setPadding(dp(16), dp(18), dp(16), dp(4));
        root.addView(header);

        TextView sub = text("Kişisel BIST30 radar + sanal broker merkezi", 13, false, MUTED);
        sub.setPadding(dp(16), 0, dp(16), dp(10));
        root.addView(sub);

        LinearLayout tabs = new LinearLayout(this);
        tabs.setOrientation(LinearLayout.HORIZONTAL);
        tabs.setPadding(dp(8), dp(4), dp(8), dp(8));
        root.addView(tabs);

        tabs.addView(tabButton("Radar", () -> showAnaRadar()));
        tabs.addView(tabButton("Detay", () -> showHisseDetay(seciliSembol)));
        tabs.addView(tabButton("Broker", () -> showSanalBroker()));
        tabs.addView(tabButton("Ayar", () -> showAyarlar()));

        ScrollView scroll = new ScrollView(this);
        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(12), dp(6), dp(12), dp(20));
        scroll.addView(content);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(root);
    }

    private TextView tabButton(String label, final Runnable action) {
        TextView b = text(label, 13, true, Color.WHITE);
        b.setGravity(Gravity.CENTER);
        b.setPadding(dp(8), dp(10), dp(8), dp(10));
        b.setBackground(round(BLUE, 14));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1);
        lp.setMargins(dp(4), 0, dp(4), 0);
        b.setLayoutParams(lp);
        b.setOnClickListener(v -> action.run());
        return b;
    }

    private void showAnaRadar() {
        content.removeAllViews();
        content.addView(sectionTitle("Ana Radar"));
        String kaynak = canliTwelveData ? "Veri kaynağı: Twelve Data / XIST / 1 gün" : "Veri kaynağı: Demo test verisi";
        content.addView(infoCard("Bugünkü durum", sonRadar.ozet.sadeMetin() + "\n\n" + kaynak));

        TextView canli = actionButton(taramaDevamEdiyor ? "Taranıyor..." : "Twelve Data ile BIST30 Tara", taramaDevamEdiyor ? GRAY : GREEN);
        canli.setEnabled(!taramaDevamEdiyor);
        canli.setOnClickListener(v -> twelveDataTara());
        content.addView(canli);

        TextView bimasTest = actionButton(taramaDevamEdiyor ? "Taranıyor..." : "BIMAS tek sembol test et", taramaDevamEdiyor ? GRAY : AMBER);
        bimasTest.setEnabled(!taramaDevamEdiyor);
        bimasTest.setOnClickListener(v -> tekSembolTest("BIMAS"));
        content.addView(bimasTest);

        TextView demo = actionButton("Demo veriye dön", BLUE);
        demo.setOnClickListener(v -> {
            sonRadar = new MiniBist30Radar().taraDemo();
            canliTwelveData = false;
            bekleyenleriYenidenKur();
            showAnaRadar();
        });
        content.addView(demo);

        for (MiniKararSonuc k : sonRadar.kararlarOku()) {
            content.addView(radarCard(k));
        }
    }

    private void twelveDataTara() {
        final String apiKey = prefs.getString("twelve_api_key", "").trim();
        if (apiKey.isEmpty()) {
            Toast.makeText(this, "Önce Ayar ekranından Twelve Data API key kaydet.", Toast.LENGTH_LONG).show();
            showAyarlar();
            return;
        }
        if (taramaDevamEdiyor) return;
        taramaDevamEdiyor = true;
        showAnaRadar();
        new Thread(() -> {
            MiniRadarSonuc sonuc = new MiniBist30Radar().taraTwelveData(apiKey);
            runOnUiThread(() -> {
                sonRadar = sonuc;
                canliTwelveData = true;
                taramaDevamEdiyor = false;
                bekleyenleriYenidenKur();
                Toast.makeText(this, "Twelve Data taraması bitti.", Toast.LENGTH_SHORT).show();
                showAnaRadar();
            });
        }).start();
    }


    private LinearLayout radarCard(final MiniKararSonuc k) {
        LinearLayout box = card();

        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);

        TextView left = text(k.sembol, 19, true, TEXT);
        top.addView(left, new LinearLayout.LayoutParams(0, -2, 1));

        TextView badge = chip(k.karar.name().replace("_", " "), colorForKarar(k.karar), Color.WHITE);
        top.addView(badge);
        box.addView(top);

        String fiyat = MiniFormat.fiyat(k.girisFiyati);
        String yon = yonMetni(k);
        String yuzde = yuzdeMetni(k);
        String puan = String.format(Locale.US, "%.1f", k.puan);
        String risk = riskKisa(k.risk.name());

        LinearLayout row1 = compactRow();
        row1.addView(infoChip("Fiyat " + fiyat, chipBg(), TEXT));
        row1.addView(infoChip(yon, yonRengi(k), Color.WHITE));
        row1.addView(infoChip("% " + yuzde, yuzdeRengi(yuzde), Color.WHITE));
        row1.addView(infoChip("Puan " + puan, chipBg(), TEXT));
        row1.addView(infoChip("Risk " + risk, riskRengi(k.risk.name()), Color.WHITE));
        box.addView(row1);

        String brokerDurumu = brokerKisa(k);
        LinearLayout row2 = compactRow();
        row2.addView(infoChip("Broker " + brokerDurumu, brokerDurumuRengi(brokerDurumu), Color.WHITE));
        row2.addView(infoChip("Giriş " + MiniFormat.fiyat(k.girisFiyati), chipBg(), TEXT));
        row2.addView(infoChip("Stop " + MiniFormat.fiyat(k.stopFiyati), chipBg(), TEXT));
        row2.addView(infoChip("Hedef " + MiniFormat.fiyat(k.hedef1Fiyati), chipBg(), TEXT));
        box.addView(row2);

        TextView yorum = small(kisaYorum(k));
        yorum.setPadding(0, dp(8), 0, 0);
        box.addView(yorum);

        box.setOnClickListener(v -> {
            seciliSembol = k.sembol;
            showHisseDetay(k.sembol);
        });
        return box;
    }

    private LinearLayout compactRow() {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setPadding(0, dp(7), 0, 0);
        row.setGravity(Gravity.CENTER_VERTICAL);
        return row;
    }

    private TextView chip(String label, int bg, int fg) {
        TextView c = text(label, 11, true, fg);
        c.setGravity(Gravity.CENTER);
        c.setPadding(dp(8), dp(5), dp(8), dp(5));
        c.setBackground(round(bg, 18));
        return c;
    }

    private TextView infoChip(String label, int bg, int fg) {
        TextView c = text(label, 10, true, fg);
        c.setGravity(Gravity.CENTER);
        c.setSingleLine(true);
        c.setPadding(dp(6), dp(4), dp(6), dp(4));
        c.setBackground(round(bg, 12));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
        lp.setMargins(0, 0, dp(5), 0);
        c.setLayoutParams(lp);
        return c;
    }

    private int chipBg() {
        return Color.rgb(238, 242, 247);
    }

    private String brokerKisa(MiniKararSonuc k) {
        if (broker.bekleyenVarMi(k.sembol)) return "15 dk";
        if (k.sanalBrokerAdayi) return "Aday";
        return "Açılmaz";
    }

    private int brokerDurumuRengi(String durum) {
        if ("15 dk".equals(durum)) return GREEN;
        if ("Aday".equals(durum)) return TEAL;
        return GRAY;
    }

    private String riskKisa(String risk) {
        if (risk == null) return "Belirsiz";
        if ("BELIRSIZ".equals(risk)) return "Belirsiz";
        if ("YUKSEK".equals(risk)) return "Yüksek";
        if ("ORTA".equals(risk)) return "Orta";
        return risk;
    }

    private int riskRengi(String risk) {
        if ("YUKSEK".equals(risk)) return RED;
        if ("ORTA".equals(risk)) return AMBER;
        return GRAY;
    }

    private String yonMetni(MiniKararSonuc k) {
        if (k.karar == KararEtiketi.ONAYLI_AL || k.karar == KararEtiketi.AL_ADAYI || k.karar == KararEtiketi.IZLE) {
            return "↑ Yukarı";
        }
        if (k.karar == KararEtiketi.UZAK_DUR) {
            return "↓ Aşağı";
        }
        return "→ Yatay";
    }

    private int yonRengi(MiniKararSonuc k) {
        if (k.karar == KararEtiketi.ONAYLI_AL || k.karar == KararEtiketi.AL_ADAYI || k.karar == KararEtiketi.IZLE) {
            return GREEN;
        }
        if (k.karar == KararEtiketi.UZAK_DUR) {
            return RED;
        }
        return GRAY;
    }

    private String yuzdeMetni(MiniKararSonuc k) {
        if (k.girisFiyati <= 0 || k.hedef1Fiyati <= 0) return "0.00";
        double raw = ((k.hedef1Fiyati - k.girisFiyati) / k.girisFiyati) * 100.0;
        double capped = raw / 10.0;
        if (k.karar == KararEtiketi.UZAK_DUR) capped = -Math.abs(capped);
        if (k.karar == KararEtiketi.BEKLE) capped = Math.max(-0.99, Math.min(0.99, capped / 2.0));
        return String.format(Locale.US, "%+.2f", capped);
    }

    private int yuzdeRengi(String yuzde) {
        if (yuzde != null && yuzde.startsWith("+")) return GREEN;
        if (yuzde != null && yuzde.startsWith("-")) return RED;
        return GRAY;
    }

    private String kisaYorum(MiniKararSonuc k) {
        if (k.aciklama == null || k.aciklama.trim().isEmpty()) return k.islemFikri;
        String a = k.aciklama.trim();
        if (a.length() > 72) a = a.substring(0, 72).trim() + "...";
        return k.islemFikri + " — " + a;
    }

    private void tekSembolTest(final String sembol) {
        final String apiKey = prefs.getString("twelve_api_key", "").trim();
        if (apiKey.isEmpty()) {
            Toast.makeText(this, "Önce Ayar ekranından Twelve Data API key kaydet.", Toast.LENGTH_LONG).show();
            showAyarlar();
            return;
        }
        if (taramaDevamEdiyor) return;
        taramaDevamEdiyor = true;
        showAnaRadar();
        new Thread(() -> {
            MiniRadarSonuc sonuc = new MiniBist30Radar().tekSembolTwelveDataTest(sembol, apiKey);
            runOnUiThread(() -> {
                sonRadar = sonuc;
                canliTwelveData = true;
                taramaDevamEdiyor = false;
                bekleyenleriYenidenKur();
                Toast.makeText(this, sembol + " test bitti.", Toast.LENGTH_SHORT).show();
                showAnaRadar();
            });
        }).start();
    }

    private void showHisseDetay(String sembol) {
        content.removeAllViews();
        seciliSembol = sembol;
        MiniKararSonuc k = kararBul(sembol);

        content.addView(sectionTitle("Hisse Detay"));
        if (k == null) {
            content.addView(infoCard("Hisse: " + sembol, "Karar bulunamadı."));
            return;
        }

        content.addView(infoCard("Hisse: " + k.sembol,
                "Karar: " + k.karar.name().replace("_", " ") + "\n" +
                "Risk: " + k.risk.name() + "\n" +
                "Puan: " + String.format(java.util.Locale.US, "%.1f", k.puan) + "\n" +
                "Giriş: " + MiniFormat.fiyat(k.girisFiyati) + "\n" +
                "Stop: " + MiniFormat.fiyat(k.stopFiyati) + "\n" +
                "Hedef 1: " + MiniFormat.fiyat(k.hedef1Fiyati) + "\n" +
                "Hedef 2: " + MiniFormat.fiyat(k.hedef2Fiyati) + "\n" +
                "Program yorumu: " + k.aciklama));

        if (k.karar == KararEtiketi.ONAYLI_AL) {
            content.addView(infoCard("Bildirim metni", bildirim.onayliAlMetni(k.sembol, k.girisFiyati, k.stopFiyati, k.hedef1Fiyati, k.hedef2Fiyati)));
        }
    }

    private void showSanalBroker() {
        content.removeAllViews();
        content.addView(sectionTitle("Sanal Broker"));
        content.addView(infoCard("Özet",
                "Sanal Bakiye: " + MiniFormat.tl(broker.bakiye) + "\n" +
                "Bekleyen Sinyal: " + broker.bekleyenler.size() + "\n" +
                "Açık İşlem: " + broker.aciklar.size() + "\n" +
                "Kapanan İşlem: " + broker.kapananlar.size()));

        boolean bekleyenAktif = false;
        for (BekleyenSinyal s : broker.bekleyenler) if (s.durum == BekleyenSinyalDurumu.ON_BES_DK_BEKLIYOR) bekleyenAktif = true;
        TextView onayla = actionButton(bekleyenAktif ? "15 dk kontrolü simüle et ve pozisyon aç" : "Bekleyen aktif sinyal yok", bekleyenAktif ? GREEN : Color.rgb(125,135,150));
        onayla.setEnabled(bekleyenAktif);
        onayla.setOnClickListener(v -> {
            Toast.makeText(this, broker.bekleyenleriOnaylaVePozisyonAc(), Toast.LENGTH_SHORT).show();
            showSanalBroker();
        });
        content.addView(onayla);

        boolean acikVar = !broker.aciklar.isEmpty();
        TextView hedef = actionButton(acikVar ? "Demo fiyat güncelle: Hedef 1 kapat" : "Açık pozisyon yok", acikVar ? BLUE : Color.rgb(125,135,150));
        hedef.setEnabled(acikVar);
        hedef.setOnClickListener(v -> {
            Toast.makeText(this, broker.demoFiyatGuncelle(), Toast.LENGTH_SHORT).show();
            showSanalBroker();
        });
        content.addView(hedef);

        if (!broker.bekleyenler.isEmpty()) {
            StringBuilder sb = new StringBuilder();
            for (BekleyenSinyal s : broker.bekleyenler) {
                sb.append(s.sembol).append(" — ").append(s.durum.name()).append("\n");
            }
            content.addView(infoCard("Bekleyen sinyaller", sb.toString()));
        }

        if (!broker.aciklar.isEmpty()) {
            StringBuilder sb = new StringBuilder();
            for (BrokerPozisyon p : broker.aciklar) {
                sb.append(p.sembol).append(" — AÇIK — Giriş: ").append(MiniFormat.fiyat(p.giris)).append("\n");
            }
            content.addView(infoCard("Açık işlemler", sb.toString()));
        }

        if (!broker.kapananlar.isEmpty()) {
            StringBuilder sb = new StringBuilder();
            for (BrokerPozisyon p : broker.kapananlar) {
                sb.append(p.sembol).append(" — ").append(p.durum.name()).append(" — Net: ").append(MiniFormat.tl(p.netKarZarar)).append("\n");
            }
            content.addView(infoCard("Kapanan işlemler", sb.toString()));
        }
    }

    private void showAyarlar() {
        content.removeAllViews();
        content.addView(sectionTitle("Ayarlar"));

        LinearLayout keyCard = card();
        keyCard.addView(text("Twelve Data API Key", 18, true, TEXT));
        EditText api = new EditText(this);
        api.setSingleLine(true);
        api.setHint("API key gir");
        api.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);
        api.setText(prefs.getString("twelve_api_key", ""));
        keyCard.addView(api);

        TextView save = actionButton("API Key Kaydet", GREEN);
        save.setOnClickListener(v -> {
            prefs.edit().putString("twelve_api_key", api.getText().toString().trim()).apply();
            Toast.makeText(this, "API key kaydedildi", Toast.LENGTH_SHORT).show();
        });
        keyCard.addView(save);
        content.addView(keyCard);

        content.addView(infoCard("Piyasa evreni", "Aktif: BIST30\nBIST50: Sonraki faz\nBIST100: Sonraki faz"));
        content.addView(infoCard("Sanal broker ayarları", "Sanal bakiye: " + MiniFormat.tl(100000) + "\nİşlem başı sanal tutar: " + MiniFormat.tl(10000) + "\nMaksimum açık işlem: 3\nGünlük maksimum işlem: 3\nRisk modu: Temkinli"));
        content.addView(infoCard("Bildirim", "Uygulama içi bildirim: Aktif\nEmail: Metin üretilecek\nWhatsApp: Otomatik gönderim yok, manuel paylaşım metni üretilecek"));
    }

    private MiniKararSonuc kararBul(String sembol) {
        for (MiniKararSonuc k : sonRadar.kararlarOku()) if (k.sembol.equals(sembol)) return k;
        return null;
    }

    private TextView actionButton(String label, int color) {
        TextView b = text(label, 15, true, Color.WHITE);
        b.setGravity(Gravity.CENTER);
        b.setPadding(dp(12), dp(11), dp(12), dp(11));
        b.setBackground(round(color, 14));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, 0, 0, dp(10));
        b.setLayoutParams(lp);
        return b;
    }

    private LinearLayout card() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(14), dp(12), dp(14), dp(12));
        box.setBackground(round(CARD, 18));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, 0, 0, dp(10));
        box.setLayoutParams(lp);
        return box;
    }

    private TextView sectionTitle(String s) {
        TextView t = text(s, 19, true, TEXT);
        t.setPadding(dp(4), dp(6), dp(4), dp(8));
        return t;
    }

    private LinearLayout infoCard(String title, String body) {
        LinearLayout box = card();
        box.addView(text(title, 17, true, TEXT));
        TextView b = text(body, 14, false, MUTED);
        b.setPadding(0, dp(6), 0, 0);
        box.addView(b);
        return box;
    }

    private TextView line(String k, String v) {
        TextView t = text(k + ": " + v, 14, false, TEXT);
        t.setPadding(0, dp(3), 0, 0);
        return t;
    }

    private TextView small(String s) {
        TextView t = text(s, 13, false, MUTED);
        t.setPadding(0, dp(8), 0, 0);
        return t;
    }

    private TextView text(String s, int sp, boolean bold, int color) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        t.setTextScaleX(1.0f);
        t.setLetterSpacing(0.0f);
        t.setIncludeFontPadding(true);
        t.setSingleLine(false);
        if (android.os.Build.VERSION.SDK_INT >= 23) {
            t.setHyphenationFrequency(Layout.HYPHENATION_FREQUENCY_NONE);
            t.setBreakStrategy(Layout.BREAK_STRATEGY_SIMPLE);
        }
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private GradientDrawable round(int color, int radius) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(radius));
        return g;
    }


    private int colorForKarar(KararEtiketi karar) {
        if (karar == KararEtiketi.ONAYLI_AL) return GREEN;
        if (karar == KararEtiketi.AL_ADAYI) return TEAL;
        if (karar == KararEtiketi.IZLE) return AMBER;
        if (karar == KararEtiketi.BEKLE) return Color.rgb(170, 110, 0);
        if (karar == KararEtiketi.VERI_YETERSIZ || karar == KararEtiketi.UZAK_DUR) return RED;
        return BLUE;
    }

    private String fmt(double v) {
        return String.format(java.util.Locale.US, "%.2f", v);
    }

    private int dp(int v) {
        return (int)(v * getResources().getDisplayMetrics().density + 0.5f);
    }
}
