package com.borsaradarmini.core.data;

import java.util.ArrayList;
import java.util.List;

public class MiniVeriMotoru {
    private final MiniTwelveDataClient client = new MiniTwelveDataClient();
    private final MiniTwelveDataParser parser = new MiniTwelveDataParser();
    private final MiniSembolCozucu sembolCozucu = new MiniSembolCozucu();

    public MiniVeriSonuc twelveDataCanli(String sembol, String apiKey) {
        List<String> hatalar = new ArrayList<>();
        for (String aday : sembolCozucu.twelveDataAdaylari(sembol)) {
            MiniHttpYaniti yanit = client.timeSeriesDaily(aday, apiKey);
            if (!yanit.basariliMi()) {
                hatalar.add(aday + " -> " + (yanit.hata == null ? "HTTP/bağlantı hatası" : yanit.hata));
                continue;
            }
            MiniVeriSonuc parsed = parser.parseTimeSeries(sembol, aday, yanit.body);
            if (parsed.basariliMi()) return parsed;
            hatalar.add(parsed.mesaj);
        }
        return MiniVeriSonuc.hata(sembol, "Twelve Data başarısız. Denenenler: " + birlestir(hatalar));
    }

    public MiniVeriSonuc demoTwelveData(String sembol) {
        if ("HEKTS".equals(sembol)) return MiniVeriSonuc.hata(sembol, "Demo veri hatası.");
        if ("SASA".equals(sembol)) return MiniVeriSonuc.yahoo(sembol, gucluMumlar(80));
        if ("ASTOR".equals(sembol)) return MiniVeriSonuc.twelve(sembol, sismisMumlar(100));
        if ("BIMAS".equals(sembol) || "THYAO".equals(sembol) || "TUPRS".equals(sembol)) return MiniVeriSonuc.twelve(sembol, gucluMumlar(100 + sembol.length()));
        return MiniVeriSonuc.twelve(sembol, zayifMumlar(100));
    }

    private String birlestir(List<String> list) {
        if (list == null || list.isEmpty()) return "Hata detayı yok.";
        StringBuilder sb = new StringBuilder();
        for (int i=0; i<list.size(); i++) { if (i>0) sb.append(" | "); sb.append(list.get(i)); }
        return sb.toString();
    }
    private List<MiniMumVerisi> gucluMumlar(double base) { List<MiniMumVerisi> m=new ArrayList<>(); for(int i=0;i<10;i++){ double c=base+i*0.8; m.add(new MiniMumVerisi(c-0.5,c+1,c-1,c,1000000+i*20000)); } return m; }
    private List<MiniMumVerisi> sismisMumlar(double base) { List<MiniMumVerisi> m=new ArrayList<>(); for(int i=0;i<10;i++){ double c=base+i*4.0; m.add(new MiniMumVerisi(c-1,c+2,c-2,c,1000000)); } return m; }
    private List<MiniMumVerisi> zayifMumlar(double base) { List<MiniMumVerisi> m=new ArrayList<>(); for(int i=0;i<10;i++){ double c=base-i*0.3; m.add(new MiniMumVerisi(c+0.2,c+0.7,c-0.7,c,700000)); } return m; }
}
