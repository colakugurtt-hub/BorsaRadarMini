package com.borsaradarmini.core.finance;

public class MiniFinansIstek {
    public final String sembol;
    public final IslemYonu islemYonu;
    public final double girisFiyati;
    public final double stopFiyati;
    public final double hedef1Fiyati;
    public final double hedef2Fiyati;
    public final double islemBasiSanalTutar;
    public final double komisyonOrani;
    public final double minimumRiskYuzdesi;
    public final double maksimumRiskYuzdesi;
    public final double minimumRiskOdul;

    public MiniFinansIstek(String sembol, IslemYonu islemYonu, double girisFiyati, double stopFiyati,
                           double hedef1Fiyati, double hedef2Fiyati, double islemBasiSanalTutar,
                           double komisyonOrani, double minimumRiskYuzdesi, double maksimumRiskYuzdesi,
                           double minimumRiskOdul) {
        this.sembol = sembol;
        this.islemYonu = islemYonu;
        this.girisFiyati = girisFiyati;
        this.stopFiyati = stopFiyati;
        this.hedef1Fiyati = hedef1Fiyati;
        this.hedef2Fiyati = hedef2Fiyati;
        this.islemBasiSanalTutar = islemBasiSanalTutar;
        this.komisyonOrani = komisyonOrani;
        this.minimumRiskYuzdesi = minimumRiskYuzdesi;
        this.maksimumRiskYuzdesi = maksimumRiskYuzdesi;
        this.minimumRiskOdul = minimumRiskOdul;
    }

    public static MiniFinansIstek al(String sembol, double giris, double stop, double hedef1, double hedef2,
                                     double tutar, double komisyon) {
        return new MiniFinansIstek(sembol, IslemYonu.AL, giris, stop, hedef1, hedef2, tutar, komisyon, 1.0, 6.0, 1.5);
    }
}
