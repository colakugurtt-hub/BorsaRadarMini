package com.borsaradarmini.core.decision;

import com.borsaradarmini.core.data.*;

import java.util.List;

public class MiniKararMotoru {
    private final MiniSinyalGuvenlikKapisi guvenlik = new MiniSinyalGuvenlikKapisi();

    public MiniKararSonuc kararVer(MiniVeriSonuc veri) {
        if (veri == null || !veri.basariliMi() || veri.mumlar == null || veri.mumlar.size() < 5) {
            return MiniKararSonuc.temel(
                    veri == null ? "-" : veri.sembol,
                    KararEtiketi.VERI_YETERSIZ,
                    RiskSeviyesi.BELIRSIZ,
                    "İşlem açılmaz",
                    false,
                    veri == null ? "Yeterli veri yok." : veri.mesaj,
                    0, 0, 0, 0);
        }

        List<MiniMumVerisi> m = veri.mumlar;
        MiniMumVerisi son = m.get(m.size() - 1);

        if (!mumlarGecerliMi(m)) {
            return MiniKararSonuc.temel(veri.sembol, KararEtiketi.VERI_YETERSIZ, RiskSeviyesi.BELIRSIZ,
                    "İşlem açılmaz", false, "Veri kalite kontrolünden geçmedi. " + veri.mesaj, 0, 0, 0, 0);
        }

        double atr = atrBenzeri(m);
        double ortHacim = ortalamaHacim(m);
        double trend = trendPuani(m);
        double guc = momentumPuani(m);
        double hacim = hacimPuani(son.volume, ortHacim);
        double puan = trend + guc + hacim;

        double giris = son.close;
        double stop = Math.max(0.01, giris - atr * 1.15);
        double hedef1 = giris + atr * 1.55;
        double hedef2 = giris + atr * 2.25;

        double dusuk = sonOnGunDusuk(m);
        double yuksek = sonOnGunYuksek(m);
        MiniSinyalGuvenlikKapisi.Sonuc gate = guvenlik.kontrolEt(giris, stop, hedef1, hedef2, son.close, dusuk, yuksek);

        String puanMetni = "Puan: " + yuvarla(puan) + ". ";

        // ONAYLI AL hâlâ sıkı: güçlü puan + tüm güvenlik kapıları şart.
        if (puan >= 68 && gate.gecer) {
            return MiniKararSonuc.temel(veri.sembol, KararEtiketi.AL_ADAYI, RiskSeviyesi.ORTA,
                    "Geri çekilmede takip edilir", true, puanMetni + gate.neden, giris, stop, hedef1, hedef2).puanla(puan);
        }

        // Güçlü ama güvenlik kapısına takılan hisseler artık UZAK DUR değil, İZLE olur.
        if (puan >= 68) {
            return MiniKararSonuc.temel(veri.sembol, KararEtiketi.IZLE, RiskSeviyesi.YUKSEK,
                    "Güçlü ama işlem açılmaz", false, puanMetni + gate.neden, giris, stop, hedef1, hedef2).puanla(puan);
        }

        if (puan >= 55) {
            return MiniKararSonuc.temel(veri.sembol, KararEtiketi.IZLE, RiskSeviyesi.ORTA,
                    "İzlenebilir", false, puanMetni + "Güç var ama ONAYLI AL için yeterli değil.", giris, stop, hedef1, hedef2).puanla(puan);
        }

        if (puan >= 32) {
            return MiniKararSonuc.temel(veri.sembol, KararEtiketi.BEKLE, RiskSeviyesi.BELIRSIZ,
                    "Bekle", false, puanMetni + "Net avantaj yok; yön teyidi beklenir.", giris, stop, hedef1, hedef2).puanla(puan);
        }

        return MiniKararSonuc.temel(veri.sembol, KararEtiketi.UZAK_DUR, RiskSeviyesi.YUKSEK,
                "Uzak dur", false, puanMetni + "Radar kriterleri zayıf.", giris, stop, hedef1, hedef2).puanla(puan);
    }

    private double sonOnGunDusuk(List<MiniMumVerisi> m) {
        int start = Math.max(0, m.size() - 10);
        double min = Double.MAX_VALUE;
        for (int i = start; i < m.size(); i++) min = Math.min(min, m.get(i).low);
        return min == Double.MAX_VALUE ? 0 : min;
    }

    private double sonOnGunYuksek(List<MiniMumVerisi> m) {
        int start = Math.max(0, m.size() - 10);
        double max = 0;
        for (int i = start; i < m.size(); i++) max = Math.max(max, m.get(i).high);
        return max;
    }

    private boolean mumlarGecerliMi(List<MiniMumVerisi> m) {
        if (m == null || m.size() < 5) return false;
        for (MiniMumVerisi x : m) {
            if (x == null || !x.gecerliMi()) return false;
        }
        return true;
    }

    private double atrBenzeri(List<MiniMumVerisi> m) {
        int start = Math.max(1, m.size() - 10);
        double toplam = 0;
        int adet = 0;
        for (int i = start; i < m.size(); i++) {
            MiniMumVerisi bugun = m.get(i);
            MiniMumVerisi onceki = m.get(i - 1);
            double tr1 = bugun.high - bugun.low;
            double tr2 = Math.abs(bugun.high - onceki.close);
            double tr3 = Math.abs(bugun.low - onceki.close);
            toplam += Math.max(tr1, Math.max(tr2, tr3));
            adet++;
        }
        return adet == 0 ? 0 : toplam / adet;
    }

    private double ortalamaHacim(List<MiniMumVerisi> m) {
        double toplam = 0;
        for (MiniMumVerisi x : m) toplam += x.volume;
        return m.isEmpty() ? 0 : toplam / m.size();
    }

    private double trendPuani(List<MiniMumVerisi> m) {
        if (m.size() < 5) return 0;
        double ilk5 = m.get(Math.max(0, m.size() - 5)).close;
        double son = m.get(m.size() - 1).close;
        double degisim5 = ilk5 > 0 ? (son - ilk5) / ilk5 : 0;

        double ilk10 = m.get(0).close;
        double degisim10 = ilk10 > 0 ? (son - ilk10) / ilk10 : 0;

        if (degisim5 > 0.055 && degisim10 > 0.035) return 35;
        if (degisim5 > 0.025 && degisim10 > 0.010) return 27;
        if (degisim5 > 0.000 || degisim10 > 0.000) return 18;
        if (degisim5 > -0.025) return 10;
        return 4;
    }

    private double momentumPuani(List<MiniMumVerisi> m) {
        if (m.size() < 3) return 0;
        MiniMumVerisi son = m.get(m.size() - 1);
        MiniMumVerisi onceki = m.get(m.size() - 2);
        MiniMumVerisi onceki2 = m.get(m.size() - 3);
        boolean ikiGunUst = son.close > onceki.close && onceki.close > onceki2.close;
        boolean pozitifMum = son.close > son.open;
        if (ikiGunUst && pozitifMum) return 25;
        if (son.close > onceki.close && pozitifMum) return 20;
        if (son.close > onceki.close) return 14;
        if (pozitifMum) return 10;
        return 5;
    }

    private double hacimPuani(long sonHacim, double ortHacim) {
        if (ortHacim <= 0) return 0;
        double oran = sonHacim / ortHacim;
        if (oran >= 1.35) return 20;
        if (oran >= 1.05) return 15;
        if (oran >= 0.75) return 10;
        return 5;
    }

    private String yuvarla(double v) {
        return String.format(java.util.Locale.US, "%.1f", v);
    }
}
