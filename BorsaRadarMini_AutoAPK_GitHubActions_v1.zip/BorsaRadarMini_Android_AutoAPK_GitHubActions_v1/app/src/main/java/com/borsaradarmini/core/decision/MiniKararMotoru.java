package com.borsaradarmini.core.decision;

import com.borsaradarmini.core.data.*;

import java.util.List;

public class MiniKararMotoru {
    private final MiniFinansMotoru finans = new MiniFinansMotoru();
    private final MiniSinyalGuvenlikKapisi guvenlik = new MiniSinyalGuvenlikKapisi();

    public MiniKararSonuc kararVer(MiniVeriSonuc veri) {
        if (veri == null || !veri.basariliMi() || veri.mumlar == null || veri.mumlar.size() < 5) {
            return MiniKararSonuc.temel(
                    veri == null ? "-" : veri.sembol,
                    KararEtiketi.VERI_YETERSIZ,
                    RiskSeviyesi.BELIRSIZ,
                    "İşlem açılmaz",
                    false,
                    veri == null ? "Yeterli veri yok." : veri.mesaj,
                    0, 0, 0, 0);
        }

        List<MiniMumVerisi> m = veri.mumlar;
        MiniMumVerisi son = m.get(m.size() - 1);

        if (!finans.mumlarGecerliMi(m)) {
            return MiniKararSonuc.temel(veri.sembol, KararEtiketi.VERI_YETERSIZ, RiskSeviyesi.BELIRSIZ,
                    "İşlem açılmaz", false, "Veri kalite kontrolünden geçmedi. " + veri.mesaj, 0, 0, 0, 0);
        }

        double atr = finans.atrBenzeri(m);
        double ortHacim = finans.ortalamaHacim(m);
        double trend = finans.trendPuani(m);
        double guc = finans.momentumPuani(m);
        double hacim = finans.hacimPuani(son.volume, ortHacim);
        double puan = trend + guc + hacim;

        double giris = son.close;
        double stop = Math.max(0.01, giris - atr * 1.15);
        double hedef1 = giris + atr * 1.55;
        double hedef2 = giris + atr * 2.25;

        double dusuk = sonOnGunDusuk(m);
        double yuksek = sonOnGunYuksek(m);
        MiniSinyalGuvenlikKapisi.Sonuc gate = guvenlik.kontrolEt(giris, stop, hedef1, hedef2, son.close, dusuk, yuksek);

        if (puan >= 72 && gate.gecer) {
            return MiniKararSonuc.temel(veri.sembol, KararEtiketi.AL_ADAYI, RiskSeviyesi.ORTA,
                    "Geri çekilmede takip edilir", true, gate.neden, giris, stop, hedef1, hedef2).puanla(puan);
        }

        if (puan >= 72) {
            return MiniKararSonuc.temel(veri.sembol, KararEtiketi.IZLE, RiskSeviyesi.YUKSEK,
                    "Güçlü ama işlem açılmaz", false, gate.neden, giris, stop, hedef1, hedef2).puanla(puan);
        }

        if (puan >= 58) {
            return MiniKararSonuc.temel(veri.sembol, KararEtiketi.IZLE, RiskSeviyesi.ORTA,
                    "İzlenebilir", false, "Güç var ama AL için yeterli değil.", giris, stop, hedef1, hedef2).puanla(puan);
        }

        if (puan >= 45) {
            return MiniKararSonuc.temel(veri.sembol, KararEtiketi.BEKLE, RiskSeviyesi.BELIRSIZ,
                    "Bekle", false, "Net avantaj yok.", giris, stop, hedef1, hedef2).puanla(puan);
        }

        return MiniKararSonuc.temel(veri.sembol, KararEtiketi.UZAK_DUR, RiskSeviyesi.YUKSEK,
                "Uzak dur", false, "Radar kriterleri zayıf.", giris, stop, hedef1, hedef2).puanla(puan);
    }

    private double sonOnGunDusuk(List<MiniMumVerisi> m) {
        int start = Math.max(0, m.size() - 10);
        double min = Double.MAX_VALUE;
        for (int i = start; i < m.size(); i++) min = Math.min(min, m.get(i).low);
        return min == Double.MAX_VALUE ? 0 : min;
    }

    private double sonOnGunYuksek(List<MiniMumVerisi> m) {
        int start = Math.max(0, m.size() - 10);
        double max = 0;
        for (int i = start; i < m.size(); i++) max = Math.max(max, m.get(i).high);
        return max;
    }
}
