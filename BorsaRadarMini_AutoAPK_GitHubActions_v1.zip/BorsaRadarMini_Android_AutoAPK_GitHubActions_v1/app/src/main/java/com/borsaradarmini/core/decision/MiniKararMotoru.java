package com.borsaradarmini.core.decision;

import com.borsaradarmini.core.data.*;
import java.util.List;

public class MiniKararMotoru {
    public MiniKararSonuc kararVer(MiniVeriSonuc veri) {
        if (veri == null || !veri.basariliMi() || veri.mumlarOku().size() < 5 || veri.sonMum() == null) {
            String s = veri == null ? "BILINMIYOR" : veri.sembol;
            return new MiniKararSonuc(s, KararEtiketi.VERI_YETERSIZ, RiskSeviyesi.BELIRSIZ,
                    veri == null ? VeriKaynagi.YOK : veri.veriKaynagi, false, 0, "İşlem açılmaz", veri == null ? "Yeterli veri yok." : veri.mesaj, 0, 0, 0, 0);
        }
        MiniMumVerisi son = veri.sonMum();
        if (!son.gecerliMi()) {
            return new MiniKararSonuc(veri.sembol, KararEtiketi.VERI_YETERSIZ, RiskSeviyesi.BELIRSIZ,
                    veri.veriKaynagi, false, 0, "İşlem açılmaz", "Veri kalite kontrolünden geçmedi. " + veri.mesaj, 0, 0, 0, 0);
        }

        List<MiniMumVerisi> m = veri.mumlarOku();
        double close = son.close;
        double avg5 = avgClose(m, 5);
        double avg10 = avgClose(m, Math.min(10, m.size()));
        double son5Getiri = yuzde(close - m.get(Math.max(0, m.size() - 5)).close, m.get(Math.max(0, m.size() - 5)).close);
        double hacimOrani = hacimOrani(m);
        double puan = 0;
        if (close > avg5) puan += 25;
        if (close > avg10) puan += 20;
        if (son5Getiri > 1 && son5Getiri <= 8) puan += 20;
        if (hacimOrani >= 0.85) puan += 15;
        if (veri.veriKaynagi == VeriKaynagi.TWELVE_DATA) puan += 20;

        double giris = close;
        double stop = close * 0.95;
        double hedef1 = close * 1.10;
        double hedef2 = close * 1.15;

        if (son5Getiri > 12) {
            return new MiniKararSonuc(veri.sembol, KararEtiketi.IZLE, RiskSeviyesi.YUKSEK, veri.veriKaynagi,
                    false, puan, "Kovalanmaz", "Fiyat kısa sürede fazla yükselmiş.", giris, stop, hedef1, hedef2);
        }
        if (veri.veriKaynagi == VeriKaynagi.YAHOO_YEDEK) {
            return new MiniKararSonuc(veri.sembol, KararEtiketi.IZLE, RiskSeviyesi.ORTA, veri.veriKaynagi,
                    false, Math.min(puan, 69), "Yedek veriyle sadece izlenir", "Yahoo yedek kaynakta sanal broker kapalıdır.", giris, stop, hedef1, hedef2);
        }
        if (puan >= 75) {
            return new MiniKararSonuc(veri.sembol, KararEtiketi.AL_ADAYI, RiskSeviyesi.ORTA, veri.veriKaynagi,
                    true, puan, "Geri çekilmede takip edilir", "AL adayı; en iyi 3 filtresine girebilir.", giris, stop, hedef1, hedef2);
        }
        if (puan >= 55) {
            return new MiniKararSonuc(veri.sembol, KararEtiketi.IZLE, RiskSeviyesi.ORTA, veri.veriKaynagi,
                    false, puan, "İzlenebilir", "Güç var ama AL için yeterli değil.", giris, stop, hedef1, hedef2);
        }
        if (puan >= 35) {
            return new MiniKararSonuc(veri.sembol, KararEtiketi.BEKLE, RiskSeviyesi.BELIRSIZ, veri.veriKaynagi,
                    false, puan, "Bekle", "Net avantaj yok.", giris, stop, hedef1, hedef2);
        }
        return new MiniKararSonuc(veri.sembol, KararEtiketi.UZAK_DUR, RiskSeviyesi.YUKSEK, veri.veriKaynagi,
                false, puan, "Uzak dur", "Radar kriterleri zayıf.", giris, stop, hedef1, hedef2);
    }

    private double avgClose(List<MiniMumVerisi> m, int n) {
        int start = Math.max(0, m.size() - n);
        double sum = 0; int count = 0;
        for (int i = start; i < m.size(); i++) { sum += m.get(i).close; count++; }
        return count == 0 ? 0 : sum / count;
    }

    private double hacimOrani(List<MiniMumVerisi> m) {
        if (m.size() < 2) return 1.0;
        MiniMumVerisi son = m.get(m.size() - 1);
        int start = Math.max(0, m.size() - 6);
        long sum = 0; int count = 0;
        for (int i = start; i < m.size() - 1; i++) { sum += m.get(i).volume; count++; }
        return count == 0 || sum <= 0 ? 1.0 : son.volume / ((double) sum / count);
    }

    private double yuzde(double fark, double baz) {
        if (baz == 0) return 0;
        return (fark / baz) * 100.0;
    }
}
