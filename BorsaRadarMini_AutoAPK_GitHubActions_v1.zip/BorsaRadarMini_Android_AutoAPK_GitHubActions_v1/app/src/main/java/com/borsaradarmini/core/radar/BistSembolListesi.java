package com.borsaradarmini.core.radar;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class BistSembolListesi {
    public List<String> getir(BistEvreni evren) {
        if (evren == BistEvreni.BIST50) {
            return new ArrayList<>(Arrays.asList(
                    "AEFES", "AKBNK", "ALARK", "ARCLK", "ASELS",
                    "ASTOR", "BIMAS", "BRSAN", "BTCIM", "CANTE",
                    "CCOLA", "CIMSA", "DOAS", "DSTKF", "EKGYO",
                    "ENKAI", "EREGL", "FROTO", "GARAN", "GUBRF",
                    "HALKB", "HEKTS", "ISCTR", "KCHOL", "KONTR",
                    "KRDMD", "KUYAS", "MAVI", "MGROS", "MIATK",
                    "OYAKC", "PASEU", "PETKM", "PGSUS", "SAHOL",
                    "SASA", "SISE", "TAVHL", "TCELL", "THYAO",
                    "TOASO", "TRALT", "TSKB", "TTKOM", "TUPRS",
                    "TURSG", "ULKER", "VAKBN", "YKBNK", "ANMET"
            ));
        }

        return new ArrayList<>(Arrays.asList(
                "AKBNK", "ASELS", "ASTOR", "BIMAS", "EREGL",
                "FROTO", "GARAN", "GUBRF", "ISCTR", "KCHOL",
                "KRDMD", "MGROS", "PETKM", "PGSUS", "SAHOL",
                "SASA", "SISE", "TCELL", "THYAO", "TOASO",
                "TUPRS", "YKBNK", "AEFES", "ALARK", "ARCLK",
                "ENKAI", "HEKTS", "KONTR", "TTKOM", "ULKER"
        ));
    }

    public int adet(BistEvreni evren) {
        return getir(evren).size();
    }

    public String ad(BistEvreni evren) {
        return evren == BistEvreni.BIST50 ? "BIST50" : "BIST30";
    }
}
