package com.borsaradarmini.core.radar;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class BistSembolListesi {
    public List<String> getir(BistEvreni evren) {
        if (evren == BistEvreni.BIST30) {
            return new ArrayList<>(Arrays.asList(
                    "AKBNK", "ALARK", "ASELS", "ASTOR", "BIMAS",
                    "DOHOL", "EKGYO", "ENKAI", "EREGL", "FROTO",
                    "GARAN", "GUBRF", "HEKTS", "ISCTR", "KCHOL",
                    "KONTR", "KOZAL", "KRDMD", "PETKM", "PGSUS",
                    "SAHOL", "SASA", "SISE", "TCELL", "THYAO",
                    "TOASO", "TUPRS", "ULKER", "YKBNK", "VESTL"
            ));
        }
        return new ArrayList<>();
    }
}
