package com.borsaradarmini.core.radar;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class BistSembolListesi {
    public List<String> getir(BistEvreni evren) {
        if (evren == BistEvreni.BIST50) {
            return new ArrayList<>(Arrays.asList(
                    "AEFES", "AKBNK", "ALARK", "ARCLK", "ASELS",
                    "ASTOR", "BIMAS", "BRSAN", "BTCIM", "CANTE",
                    "CCOLA", "CIMSA", "DOAS", "DOHOL", "EKGYO",
                    "ENKAI", "EREGL", "FROTO", "GARAN", "GUBRF",
                    "HALKB", "HEKTS", "ISCTR", "KCHOL", "KONTR",
                    "KRDMD", "MAVI", "MGROS", "MIATK", "OYAKC",
                    "PETKM", "PGSUS", "SAHOL", "SASA", "SISE",
                    "TAVHL", "TCELL", "THYAO", "TOASO", "TSKB",
                    "TTKOM", "TUPRS", "TURSG", "ULKER", "VAKBN",
                    "VESTL", "YKBNK", "KONYA", "ENJSA", "TTRAK"
            ));
        }

        return new ArrayList<>(Arrays.asList(
                "AKBNK", "ALARK", "ASELS", "ASTOR", "BIMAS",
                "EKGYO", "ENKAI", "EREGL", "FROTO", "GARAN",
                "GUBRF", "HEKTS", "ISCTR", "KCHOL", "KONTR",
                "KRDMD", "MGROS", "PETKM", "PGSUS", "SAHOL",
                "SASA", "SISE", "TCELL", "THYAO", "TOASO",
                "TUPRS", "ULKER", "YKBNK", "ARCLK", "DOHOL"
        ));
    }

    public int adet(BistEvreni evren) {
        return getir(evren).size();
    }

    public String ad(BistEvreni evren) {
        return evren == BistEvreni.BIST50 ? "BIST50" : "BIST30";
    }
}
