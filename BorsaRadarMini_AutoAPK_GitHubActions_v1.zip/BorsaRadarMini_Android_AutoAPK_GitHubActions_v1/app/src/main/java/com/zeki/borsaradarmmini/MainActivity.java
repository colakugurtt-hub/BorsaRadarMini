
package com.zeki.borsaradarmmini;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.*;
import android.widget.*;
import android.text.*;
import android.text.method.ScrollingMovementMethod;

import org.json.*;

import java.io.*;
import java.net.*;
import java.util.*;
import java.util.concurrent.*;

public class MainActivity extends Activity {
    private LinearLayout root;
    private TextView status;
    private TextView radarBox;
    private TextView brokerBox;
    private Button scanButton;
    private Button updateButton;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private static final int BG = Color.rgb(17,24,39);
    private static final int CARD = Color.rgb(31,41,55);
    private static final int TXT = Color.rgb(229,231,235);
    private static final int MUTED = Color.rgb(156,163,175);

    private final String[] symbols = new String[]{
            "AKBNK.IS","ALARK.IS","ASELS.IS","ASTOR.IS","BIMAS.IS",
            "DOAS.IS","EKGYO.IS","ENKAI.IS","EREGL.IS","FROTO.IS",
            "GARAN.IS","GUBRF.IS","HEKTS.IS","ISCTR.IS","KCHOL.IS",
            "KONTR.IS","KOZAA.IS","KOZAL.IS","KRDMD.IS","ODAS.IS",
            "PETKM.IS","PGSUS.IS","SAHOL.IS","SASA.IS","SISE.IS",
            "TCELL.IS","THYAO.IS","TOASO.IS","TUPRS.IS","YKBNK.IS"
    };

    public void onCreate(Bundle b) {
        super.onCreate(b);
        buildUi();
        renderBroker();
    }

    private TextView tv(String text, int sp, int color, int style) {
        TextView v = new TextView(this);
        v.setText(text);
        v.setTextSize(sp);
        v.setTextColor(color);
        v.setTypeface(Typeface.DEFAULT, style);
        v.setPadding(dp(12), dp(8), dp(12), dp(8));
        return v;
    }

    private TextView cardText(String text) {
        TextView v = tv(text, 15, TXT, Typeface.NORMAL);
        v.setBackgroundColor(CARD);
        v.setMovementMethod(new ScrollingMovementMethod());
        return v;
    }

    private Button btn(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextColor(Color.WHITE);
        b.setTextSize(15);
        b.setAllCaps(false);
        return b;
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(10), dp(12), dp(10), dp(20));
        root.setBackgroundColor(BG);
        scroll.addView(root);

        root.addView(tv("Borsa Radar Mini", 25, TXT, Typeface.BOLD));
        root.addView(tv("KararMotoru'ndan tamamen ayrı kişisel APK deneme sistemi. Gerçek emir yoktur.", 14, MUTED, Typeface.NORMAL));

        scanButton = btn("BIST30 Tara ve Sanal İşlem Aç");
        updateButton = btn("Sanal İşlemleri Güncelle");

        root.addView(scanButton);
        root.addView(updateButton);

        status = tv("Hazır. İlk taramayı başlatabilirsin.", 14, MUTED, Typeface.NORMAL);
        root.addView(status);

        root.addView(tv("Radar Sonucu", 20, TXT, Typeface.BOLD));
        radarBox = cardText("Henüz tarama yapılmadı.");
        root.addView(radarBox, new LinearLayout.LayoutParams(-1, -2));

        root.addView(tv("Sanal Broker Defteri", 20, TXT, Typeface.BOLD));
        brokerBox = cardText("");
        root.addView(brokerBox, new LinearLayout.LayoutParams(-1, -2));

        root.addView(tv("Uyarı: Bu uygulama yatırım tavsiyesi vermez. Ücretsiz veri gecikebilir veya hatalı olabilir. Sadece sanal deneme ve öğrenme içindir.", 13, MUTED, Typeface.NORMAL));

        scanButton.setOnClickListener(v -> scan());
        updateButton.setOnClickListener(v -> updateTrades());
        setContentView(scroll);
    }

    private void scan() {
        scanButton.setEnabled(false);
        status.setText("BIST30 taranıyor. Bu işlem mobil internette biraz sürebilir...");
        radarBox.setText("");

        executor.execute(() -> {
            ArrayList<Signal> signals = new ArrayList<>();
            int done = 0;
            for (String s : symbols) {
                try {
                    MarketData md = fetchMarketData(s);
                    Signal sig = analyze(s, md);
                    signals.add(sig);
                } catch (Exception e) {
                    signals.add(Signal.error(clean(s), "Veri alınamadı: " + e.getMessage()));
                }
                done++;
                final int progress = done;
                mainHandler.post(() -> status.setText("Taranıyor: " + progress + " / " + symbols.length));
            }

            Collections.sort(signals, (a,b) -> {
                int da = decisionRank(a.decision);
                int db = decisionRank(b.decision);
                if (da != db) return da - db;
                return b.score - a.score;
            });

            int opened = autoOpenVirtualTrades(signals);

            StringBuilder out = new StringBuilder();
            out.append("Bugünün radar sonucu\\n\\n");
            for (int i=0; i<signals.size(); i++) {
                Signal x = signals.get(i);
                out.append(i+1).append(") ").append(x.symbol)
                        .append(" — ").append(x.decision)
                        .append(" | Risk: ").append(x.risk)
                        .append(" | Puan: ").append(x.score).append("\\n");
                out.append("Giriş: ").append(fmt(x.entry))
                        .append(" | Stop: ").append(fmt(x.stop))
                        .append(" | Hedef: ").append(fmt(x.target)).append("\\n");
                out.append(x.comment).append("\\n\\n");
            }
            out.append("Açılan yeni sanal işlem: ").append(opened).append("\\n");

            mainHandler.post(() -> {
                radarBox.setText(out.toString());
                renderBroker();
                status.setText("Tarama bitti.");
                scanButton.setEnabled(true);
            });
        });
    }

    private int decisionRank(String d) {
        if ("İzlenebilir".equals(d)) return 0;
        if ("Bekle".equals(d)) return 1;
        return 2;
    }

    private String clean(String s) { return s.replace(".IS", ""); }

    private MarketData fetchMarketData(String symbol) throws Exception {
        String url = "https://query1.finance.yahoo.com/v8/finance/chart/" + URLEncoder.encode(symbol, "UTF-8") + "?range=6mo&interval=1d";
        HttpURLConnection con = (HttpURLConnection)new URL(url).openConnection();
        con.setRequestMethod("GET");
        con.setConnectTimeout(15000);
        con.setReadTimeout(20000);
        con.setRequestProperty("User-Agent", "Mozilla/5.0");
        int code = con.getResponseCode();
        if (code < 200 || code >= 300) throw new IOException("HTTP " + code);

        BufferedReader br = new BufferedReader(new InputStreamReader(con.getInputStream()));
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = br.readLine()) != null) sb.append(line);
        br.close();

        JSONObject root = new JSONObject(sb.toString());
        JSONObject result = root.getJSONObject("chart").getJSONArray("result").getJSONObject(0);
        JSONObject quote = result.getJSONObject("indicators").getJSONArray("quote").getJSONObject(0);
        JSONArray close = quote.getJSONArray("close");
        JSONArray high = quote.getJSONArray("high");
        JSONArray low = quote.getJSONArray("low");
        JSONArray volume = quote.getJSONArray("volume");

        MarketData md = new MarketData();
        for (int i=0; i<close.length(); i++) {
            if (!close.isNull(i) && !high.isNull(i) && !low.isNull(i) && !volume.isNull(i)) {
                md.close.add(close.getDouble(i));
                md.high.add(high.getDouble(i));
                md.low.add(low.getDouble(i));
                md.volume.add(volume.getDouble(i));
            }
        }
        if (md.close.size() < 60) throw new IOException("Yetersiz veri");
        return md;
    }

    private Signal analyze(String rawSymbol, MarketData md) {
        String symbol = clean(rawSymbol);
        int n = md.close.size();
        double last = md.close.get(n-1);
        double prev = md.close.get(n-2);
        double avg20 = avg(md.close, n-20, n);
        double avg50 = avg(md.close, n-50, n);
        double vol20 = avg(md.volume, n-20, n);
        double lastVol = md.volume.get(n-1);
        double recentHigh = max(md.high, n-20, n);
        double recentLow = min(md.low, n-20, n);

        int score = 0;
        ArrayList<String> good = new ArrayList<>();
        ArrayList<String> bad = new ArrayList<>();

        if (last > avg20) { score += 20; good.add("son hareket toparlanmış"); }
        else bad.add("kısa vadede zayıf");

        if (last > avg50) { score += 20; good.add("genel duruş olumlu"); }
        else bad.add("genel duruş zayıf");

        if (last > prev) { score += 10; good.add("son kapanışta yukarı istek var"); }
        else bad.add("son kapanışta alıcı net değil");

        if (lastVol > vol20 * 1.15) { score += 20; good.add("ilgi artışı var"); }
        else if (lastVol < vol20 * 0.75) bad.add("ilgi zayıf");

        double distanceToHigh = (recentHigh - last) / last;
        double distanceToLow = (last - recentLow) / last;

        if (distanceToHigh >= 0.015 && distanceToHigh <= 0.10) { score += 15; good.add("yukarı alanı tamamen kapanmamış"); }
        else if (distanceToHigh < 0.015) bad.add("tepe bölgesine çok yakın, kovalanmaz");

        if (distanceToLow > 0.025) score += 15;
        else bad.add("aşağı risk bölgesine yakın");

        score = Math.max(0, Math.min(100, score));
        double stop = round2(recentLow * 0.995);
        double entry = round2(last);
        double target = round2(last + (last - stop) * 2.0);

        String decision, risk, comment;
        if (score >= 70 && stop < entry && entry < target) {
            decision = "İzlenebilir";
            risk = "Orta";
            comment = "Bugün dikkat çekiyor. " + join(good, 3) + ". Sert yükseliş olursa kovalanmaz.";
        } else if (score >= 45) {
            decision = "Bekle";
            risk = "Orta-Yüksek";
            comment = "Hareket var ama net alım için erken. " + join(mix(bad, good), 3) + ".";
        } else {
            decision = "Uzak dur";
            risk = "Yüksek";
            comment = "Şu an işlem için zayıf görünüyor. " + join(bad, 3) + ".";
        }
        return new Signal(symbol, decision, risk, entry, stop, target, score, comment);
    }

    private ArrayList<String> mix(ArrayList<String> a, ArrayList<String> b) {
        ArrayList<String> x = new ArrayList<>();
        x.addAll(a); x.addAll(b);
        return x;
    }

    private String join(ArrayList<String> list, int max) {
        if (list.size() == 0) return "belirgin avantaj yok";
        StringBuilder sb = new StringBuilder();
        for (int i=0; i<list.size() && i<max; i++) {
            if (i>0) sb.append(", ");
            sb.append(list.get(i));
        }
        return sb.toString();
    }

    private double avg(ArrayList<Double> a, int start, int end) {
        start = Math.max(0, start);
        double s=0; int c=0;
        for (int i=start; i<end && i<a.size(); i++) { s += a.get(i); c++; }
        return c == 0 ? 0 : s/c;
    }

    private double max(ArrayList<Double> a, int start, int end) {
        start = Math.max(0, start);
        double m = -Double.MAX_VALUE;
        for (int i=start; i<end && i<a.size(); i++) m = Math.max(m, a.get(i));
        return m;
    }

    private double min(ArrayList<Double> a, int start, int end) {
        start = Math.max(0, start);
        double m = Double.MAX_VALUE;
        for (int i=start; i<end && i<a.size(); i++) m = Math.min(m, a.get(i));
        return m;
    }

    private double round2(double x) { return Math.round(x * 100.0) / 100.0; }
    private String fmt(double x) { return String.format(Locale.US, "%.2f", x); }

    private int autoOpenVirtualTrades(ArrayList<Signal> signals) {
        JSONArray trades = getTrades();
        int opened = 0;
        for (Signal s : signals) {
            if (opened >= 3) break;
            if (!"İzlenebilir".equals(s.decision)) continue;
            if (hasOpen(trades, s.symbol)) continue;
            if (!(s.stop < s.entry && s.entry < s.target)) continue;

            int qty = Math.max(1, (int)Math.floor(10000.0 / s.entry));
            JSONObject t = new JSONObject();
            try {
                t.put("symbol", s.symbol);
                t.put("status", "OPEN");
                t.put("entry", s.entry);
                t.put("stop", s.stop);
                t.put("target", s.target);
                t.put("qty", qty);
                t.put("pnl", 0.0);
                t.put("note", "Radar otomatik sanal işlem açtı. Gerçek emir değildir.");
                trades.put(t);
                opened++;
            } catch (JSONException ignored) {}
        }
        saveTrades(trades);
        return opened;
    }

    private boolean hasOpen(JSONArray trades, String symbol) {
        for (int i=0; i<trades.length(); i++) {
            try {
                JSONObject t = trades.getJSONObject(i);
                if (symbol.equals(t.getString("symbol")) && "OPEN".equals(t.getString("status"))) return true;
            } catch (Exception ignored) {}
        }
        return false;
    }

    private void updateTrades() {
        updateButton.setEnabled(false);
        status.setText("Sanal işlemler güncelleniyor...");
        executor.execute(() -> {
            JSONArray trades = getTrades();
            int closed = 0;
            for (int i=0; i<trades.length(); i++) {
                try {
                    JSONObject t = trades.getJSONObject(i);
                    if (!"OPEN".equals(t.getString("status"))) continue;
                    String symbol = t.getString("symbol") + ".IS";
                    MarketData md = fetchMarketData(symbol);
                    double price = md.close.get(md.close.size()-1);
                    double entry = t.getDouble("entry");
                    double stop = t.getDouble("stop");
                    double target = t.getDouble("target");
                    int qty = t.getInt("qty");
                    if (price <= stop) {
                        t.put("status", "CLOSED");
                        t.put("exit", round2(price));
                        t.put("pnl", round2((price-entry)*qty));
                        t.put("note", "Stop seviyesine geldi. Sanal zarar.");
                        closed++;
                    } else if (price >= target) {
                        t.put("status", "CLOSED");
                        t.put("exit", round2(price));
                        t.put("pnl", round2((price-entry)*qty));
                        t.put("note", "Hedefe geldi. Sanal kâr.");
                        closed++;
                    }
                } catch (Exception ignored) {}
            }
            saveTrades(trades);
            int finalClosed = closed;
            mainHandler.post(() -> {
                renderBroker();
                status.setText("Güncelleme bitti. Kapanan sanal işlem: " + finalClosed);
                updateButton.setEnabled(true);
            });
        });
    }

    private JSONArray getTrades() {
        String s = getSharedPreferences("brm", MODE_PRIVATE).getString("trades", "[]");
        try { return new JSONArray(s); } catch (Exception e) { return new JSONArray(); }
    }

    private void saveTrades(JSONArray arr) {
        getSharedPreferences("brm", MODE_PRIVATE).edit().putString("trades", arr.toString()).apply();
    }

    private void renderBroker() {
        JSONArray trades = getTrades();
        int open=0, closed=0, win=0, loss=0;
        double pnl=0;
        StringBuilder sb = new StringBuilder();

        for (int i=trades.length()-1; i>=0; i--) {
            try {
                JSONObject t = trades.getJSONObject(i);
                String status = t.getString("status");
                if ("OPEN".equals(status)) open++; else closed++;
                double p = t.optDouble("pnl", 0.0);
                if (!"OPEN".equals(status)) {
                    pnl += p;
                    if (p > 0) win++; else loss++;
                }
            } catch (Exception ignored) {}
        }
        double wr = closed == 0 ? 0 : (win * 100.0 / closed);
        sb.append("Açık işlem: ").append(open)
                .append(" | Kapanan: ").append(closed)
                .append(" | Başarı: ").append(String.format(Locale.US, "%.1f", wr)).append("%")
                .append(" | Toplam: ").append(String.format(Locale.US, "%.2f", pnl)).append(" TL\\n\\n");

        for (int i=trades.length()-1; i>=0 && i>=trades.length()-30; i--) {
            try {
                JSONObject t = trades.getJSONObject(i);
                sb.append(t.getString("symbol")).append(" — ").append(t.getString("status")).append("\\n");
                sb.append("Giriş: ").append(fmt(t.getDouble("entry")))
                        .append(" | Stop: ").append(fmt(t.getDouble("stop")))
                        .append(" | Hedef: ").append(fmt(t.getDouble("target")))
                        .append(" | Adet: ").append(t.getInt("qty")).append("\\n");
                sb.append("Sonuç: ").append(String.format(Locale.US, "%.2f", t.optDouble("pnl", 0.0))).append(" TL\\n");
                sb.append(t.optString("note", "")).append("\\n\\n");
            } catch (Exception ignored) {}
        }
        if (trades.length() == 0) sb.append("Henüz sanal işlem yok.");
        brokerBox.setText(sb.toString());
    }

    private int dp(int v) { return (int)(v * getResources().getDisplayMetrics().density); }

    static class MarketData {
        ArrayList<Double> close = new ArrayList<>();
        ArrayList<Double> high = new ArrayList<>();
        ArrayList<Double> low = new ArrayList<>();
        ArrayList<Double> volume = new ArrayList<>();
    }

    static class Signal {
        String symbol, decision, risk, comment;
        double entry, stop, target;
        int score;

        Signal(String symbol, String decision, String risk, double entry, double stop, double target, int score, String comment) {
            this.symbol=symbol; this.decision=decision; this.risk=risk; this.entry=entry; this.stop=stop; this.target=target; this.score=score; this.comment=comment;
        }

        static Signal error(String symbol, String msg) {
            return new Signal(symbol, "Uzak dur", "Yüksek", 0,0,0,0,msg);
        }
    }
}
