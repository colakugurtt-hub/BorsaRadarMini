# Borsa Radar Mini v2 — Faz 12.1 PASS Raporu

## Faz
Faz 12.1 — Sembol Çözümleme + Gerçek Hata Mesajı

## Yeni deneme sırası

```text
BIMAS
BIMAS:XIST
BIMAS.IS
```

Bu sıra KararMotoru tarafında daha önce görülen `BIMAS.IS çekmiyor, BIMAS çekiyor` davranışına göre belirlendi.

## Eklenenler

```text
MiniSembolCozucu.java
MiniTwelveDataClient.java güncellendi
MiniTwelveDataParser.java hata okuma güçlendirildi
MiniVeriMotoru.java aday format deneme sırası eklendi
MiniKararMotoru.java veri yetersiz mesajını gerçek hata ile gösteriyor
MiniBist30Radar.java tek sembol test metodu
MainActivity.java BIMAS tek sembol test butonu
```

## Test akışı

1. APK kurulur.
2. Ayar ekranında API key kaydedilir.
3. Radar ekranında önce `BIMAS tek sembol test et` butonuna basılır.
4. BIMAS veri alırsa BIST30 toplu tarama denenir.
5. BIMAS da veri alamazsa kartta gerçek Twelve Data hata mesajı okunur.
