# Faz 12 APK Üretim Adımları

1. Bu ZIP'i `C:\BRM_TEST_FAZ12` gibi Türkçe karakter içermeyen bir klasöre çıkar.
2. Android Studio > Open ile klasörü aç.
3. Gradle Sync bitmesini bekle.
4. Üst menüden:

```text
Build > Generate App Bundles or APKs > Generate APKs
```

5. APK yolu:

```text
C:\BRM_TEST_FAZ12\app\build\outputs\apk\debug\app-debug.apk
```

6. APK'yı telefona gönderip kur.
7. Uygulamada Ayar ekranından Twelve Data API key kaydet.
8. Radar ekranında `Twelve Data ile BIST30 Tara` butonuna bas.
