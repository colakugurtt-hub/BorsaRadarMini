# Borsa Radar Mini v2 — Faz 12 PASS Raporu

## Faz
Faz 12 — Twelve Data Canlı Bağlantı + UI Format Düzeltmeleri

## Eklenenler

```text
MiniTwelveDataClient.java
MiniTwelveDataParser.java
MiniFormat.java
MiniVeriMotoru canlı Twelve Data metodu
MiniBist30Radar canlı tarama metodu
MainActivity canlı tarama butonu
```

## Twelve Data Kullanımı

İstek formatı:

```text
https://api.twelvedata.com/time_series?symbol=BIMAS&exchange=XIST&interval=1day&outputsize=10&apikey=...
```

## Kurallar

- API key boşsa canlı tarama çalışmaz.
- Twelve Data hata dönerse ilgili sembol VERİ YETERSİZ olur.
- BIST tarafı XIST / 1day çalışır.
- Demo veriye dönüş butonu korunur.
- Broker gerçek emir göndermez; sanal kalır.
- WhatsApp otomatik gönderim yoktur.

## UI Düzeltmeleri

- TL formatı Türkçe biçime alındı.
- Broker butonları duruma göre aktif/pasif yapılır.
- TextView harf aralığı/satır kırma ayarları düzeltildi.

## Karar
Faz 12 kaynak paketi hazır. Android Studio ile tekrar APK üretilecek.
