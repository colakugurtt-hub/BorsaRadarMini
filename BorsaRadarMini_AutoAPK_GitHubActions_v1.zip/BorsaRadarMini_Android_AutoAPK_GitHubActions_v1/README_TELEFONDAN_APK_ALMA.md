# Telefondan Hazır APK Alma - Borsa Radar Mini

Bu paket GitHub Actions ile otomatik APK üretecek şekilde hazırlandı.

## Ne yapacaksın?

1. GitHub hesabına gir.
2. Yeni repository aç.
3. Bu ZIP'in içindeki dosyaları repository içine yükle.
4. GitHub Actions sekmesine gir.
5. `Build Borsa Radar Mini APK` workflow'unu çalıştır.
6. İşlem bitince `Artifacts` bölümünden `BorsaRadarMini-debug-apk` dosyasını indir.
7. ZIP içinden `app-debug.apk` dosyasını çıkar.
8. Telefonda kur.

## Önemli

- APK debug APK'dır.
- Google Play'e yüklemek için değil, kişisel telefonda denemek içindir.
- Kurarken Android "bilinmeyen kaynak" izni isteyebilir.
- Gerçek emir göndermez.
- KararMotoru ile bağlantısı yoktur.
- Ücretsiz veri kaynağı garanti değildir.

## Uygulamada ne var?

- BIST30 tarama
- Sade karar: İzlenebilir / Bekle / Uzak dur
- Sanal broker
- Sanal kâr/zarar
- Mobil internetle çalışma denemesi
