# Faz 12.1 APK Üretim Adımları

1. ZIP'i `C:\BRM_TEST_FAZ12_1` klasörüne çıkar.
2. Android Studio > Open ile bu klasörü aç.
3. Sync bitince: Build > Generate App Bundles or APKs > Generate APKs
4. APK yolu: `C:\BRM_TEST_FAZ12_1\app\build\outputs\apk\debug\app-debug.apk`
5. Telefona kur.
6. Ayar ekranından API key kaydet.
7. Radar ekranında önce `BIMAS tek sembol test et` butonuna bas.
