# Borsa Radar Mini - Android APK Kaynak Paketi v1

Bu paket KararMotoru'ndan tamamen ayrıdır.

## Ne var?

- Android native Java uygulama kaynak kodu
- Sadece telefon için düşünülmüş yapı
- PC/VPS zorunlu değil
- Mobil internet ile ücretsiz veri çekmeye çalışır
- BIST30 tarar
- Sade yorum verir:
  - İzlenebilir
  - Bekle
  - Uzak dur
- Sanal broker defteri tutar
- Gerçek emir göndermez
- Banka/aracı kurum bağlantısı yoktur

## Önemli gerçek

Bu ZIP doğrudan APK değildir. APK oluşturmak için Android Studio veya online Android build servisi gerekir.

Benim bulunduğum ortamda Android SDK / Gradle build sistemi olmadığı için imzalı APK dosyasını burada derleyemiyorum. Bu paket, APK üretilecek kaynak projedir.

## Android Studio ile APK alma

1. Android Studio kurulu bir cihazda `BorsaRadarMini_Android_Source_v1` klasörünü aç.
2. Gradle Sync işlemini bekle.
3. Build > Build Bundle(s) / APK(s) > Build APK(s)
4. Oluşan APK'yı telefona gönder.
5. Telefonda bilinmeyen kaynaklardan kuruluma izin ver.

## Uyarı

Ücretsiz veri kaynağı garanti değildir. Veri gelmezse uygulama bazı hisselerde 'veri alınamadı' diyebilir.
Bu uygulama yatırım tavsiyesi vermez. Sadece kişisel simülasyon ve öğrenme aracıdır.
