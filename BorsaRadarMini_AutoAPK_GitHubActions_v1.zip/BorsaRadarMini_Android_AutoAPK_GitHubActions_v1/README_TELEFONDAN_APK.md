# Borsa Radar Mini v2 — Faz 11 GitHub Actions APK Test Rehberi

## Amaç

Bu paket, BorsaRadarMini v2 projesini GitHub Actions ile APK üretim testine sokmak için hazırlanmıştır.

## En Önemli Nokta

Bu ZIP'i GitHub'a ZIP olarak bırakmak yerine, içindeki dosyalar repo köküne çıkarılmış halde yüklenmelidir.

Repo kökünde şunlar görünmeli:

```text
.github/workflows/build-v2-apk.yml
app/
settings.gradle
build.gradle
README_TELEFONDAN_APK.md
CHANGELOG.md
BorsaRadarMini_v2_SPEC.md
```

## Telefonda GitHub'a Yükleme Mantığı

1. ZIP'i telefona indir.
2. Telefonda ZIP'i çıkar.
3. GitHub repo ana ekranına gir.
4. Dosyaları repo köküne yükle.
5. `.github/workflows/build-v2-apk.yml` dosyasının repo içinde gerçek dosya olarak göründüğünden emin ol.
6. Actions sekmesine gir.
7. `Build BorsaRadarMini v2 APK` workflow'unu çalıştır.
8. Yeşil tik geldikten sonra artifact indir.

## Artifact Adı

```text
BorsaRadarMini-v2-debug-apk
```

İndirilen artifact ZIP içinden çıkacak APK:

```text
app-debug.apk
```

## Kurulum

1. Artifact ZIP'i indir.
2. ZIP'i çıkar.
3. `app-debug.apk` dosyasına bas.
4. Android izin isterse bu kaynaktan yüklemeye izin ver.
5. Uygulamayı aç.

## İlk Kontrol

Uygulama açıldığında şu ekranları görmelisin:

```text
Ana Radar
Hisse Detay
Sanal Broker
Ayarlar
```

Ayarlar ekranında:

```text
Twelve Data API Key
API Key Kaydet
```

alanı görünmeli.

## Faz 11 Sınırı

Bu APK, birleşik test APK'sıdır. Demo veri motoru bağlıdır. Gerçek Twelve Data canlı HTTP bağlantısı sonraki fazda bağlanacaktır.
