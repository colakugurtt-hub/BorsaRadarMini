package com.borsaradarmini;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.content.SharedPreferences;
import android.view.Gravity;
import android.widget.*;
import android.text.InputType;
import android.graphics.drawable.GradientDrawable;
import android.text.Layout;

import com.borsaradarmini.core.radar.*;
import com.borsaradarmini.core.decision.*;
import com.borsaradarmini.core.broker.*;
import com.borsaradarmini.core.notification.*;
import com.borsaradarmini.core.util.MiniFormat;

import java.util.List;

public class MainActivity extends Activity {
    private LinearLayout root;
    private LinearLayout content;
    private SharedPreferences prefs;
    private MiniRadarSonuc sonRadar;
    private MiniSanalBroker broker = new MiniSanalBroker();
    private MiniBildirimMotoru bildirim = new MiniBildirimMotoru();
    private String seciliSembol = "BIMAS";
    private boolean canliTwelveData = false;
    private boolean taramaDevamEdiyor = false;

    private final int BG = Color.rgb(245, 247, 250);
    private final int CARD = Color.WHITE;
    private final int TEXT = Color.rgb(20, 28, 38);
    private final int MUTED = Color.rgb(95, 108, 125);
    private final int BLUE = Color.rgb(31, 111, 235);
    private final int GREEN = Color.rgb(28, 135, 85);
    private final int RED = Color.rgb(185, 28, 28);
    private final int AMBER = Color.rgb(180, 105, 0);

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences("borsa_radar_mini_v2", MODE_PRIVATE);
        sonRadar = new MiniBist30Radar().taraDemo();
        for (MiniKararSonuc k : sonRadar.kararlarOku()) {
            if (k.karar == KararEtiketi.ONAYLI_AL) broker.bekleyenSinyalEkle(new BekleyenSinyal(k));
        }
        buildShell();
        showAnaRadar();
    }

    private void buildShell() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);

        TextView header = text("Borsa Radar Mini v2", 22, true, TEXT);
        header.setPadding(dp(16), dp(18), dp(16), dp(4));
        root.addView(header);

        TextView sub = text("Kişisel BIST30 radar + sanal broker merkezi", 13, false, MUTED);
        sub.setPadding(dp(16), 0, dp(16), dp(10));
        root.addView(sub);

        LinearLayout tabs = new LinearLayout(this);
        tabs.setOrientation(LinearLayout.HORIZONTAL);
        tabs.setPadding(dp(8), dp(4), dp(8), dp(8));
        root.addView(tabs);

        tabs.addView(tabButton("Radar", () -> showAnaRadar()));
        tabs.addView(tabButton("Detay", () -> showHisseDetay(seciliSembol)));
        tabs.addView(tabButton("Broker", () -> showSanalBroker()));
        tabs.addView(tabButton("Ayar", () -> showAyarlar()));

        ScrollView scroll = new ScrollView(this);
        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(12), dp(6), dp(12), dp(20));
        scroll.addView(content);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(root);
    }

    private TextView tabButton(String label, final Runnable action) {
        TextView b = text(label, 13, true, Color.WHITE);
        b.setGravity(Gravity.CENTER);
        b.setPadding(dp(8), dp(10), dp(8), dp(10));
        b.setBackground(round(BLUE, 14));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1);
        lp.setMargins(dp(4), 0, dp(4), 0);
        b.setLayoutParams(lp);
        b.setOnClickListener(v -> action.run());
        return b;
    }

    private void showAnaRadar() {
        content.removeAllViews();
        content.addView(sectionTitle("Ana Radar"));
        String kaynak = canliTwelveData ? "Veri kaynağı: Twelve Data / XIST / 1 gün" : "Veri kaynağı: Demo test verisi";
        content.addView(infoCard("Bugünkü durum", sonRadar.ozet.sadeMetin() + "\n\n" + kaynak));

        TextView canli = actionButton(taramaDevamEdiyor ? "Taranıyor..." : "Twelve Data ile BIST30 Tara", taramaDevamEdiyor ? Color.rgb(125,135,150) : GREEN);
        canli.setEnabled(!taramaDevamEdiyor);
        canli.setOnClickListener(v -> twelveDataTara());
        content.addView(canli);

        TextView demo = actionButton("Demo veriye dön", BLUE);
        demo.setOnClickListener(v -> {
            sonRadar = new MiniBist30Radar().taraDemo();
            canliTwelveData = false;
            broker = new MiniSanalBroker();
            for (MiniKararSonuc k : sonRadar.kararlarOku()) if (k.karar == KararEtiketi.ONAYLI_AL) broker.bekleyenSinyalEkle(new BekleyenSinyal(k));
            showAnaRadar();
        });
        content.addView(demo);

        for (MiniKararSonuc k : sonRadar.kararlarOku()) {
            content.addView(radarCard(k));
        }
    }

    private void twelveDataTara() {
        final String apiKey = prefs.getString("twelve_api_key", "").trim();
        if (apiKey.isEmpty()) {
            Toast.makeText(this, "Önce Ayar ekranından Twelve Data API key kaydet.", Toast.LENGTH_LONG).show();
            showAyarlar();
            return;
        }
        if (taramaDevamEdiyor) return;
        taramaDevamEdiyor = true;
        showAnaRadar();
        new Thread(() -> {
            MiniRadarSonuc sonuc = new MiniBist30Radar().taraTwelveData(apiKey);
            runOnUiThread(() -> {
                sonRadar = sonuc;
                canliTwelveData = true;
                taramaDevamEdiyor = false;
                broker = new MiniSanalBroker();
                for (MiniKararSonuc k : sonRadar.kararlarOku()) if (k.karar == KararEtiketi.ONAYLI_AL) broker.bekleyenSinyalEkle(new BekleyenSinyal(k));
                Toast.makeText(this, "Twelve Data taraması bitti.", Toast.LENGTH_SHORT).show();
                showAnaRadar();
            });
        }).start();
    }

    private LinearLayout radarCard(final MiniKararSonuc k) {
        LinearLayout box = card();
        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);

        TextView left = text(k.sembol, 20, true, TEXT);
        top.addView(left, new LinearLayout.LayoutParams(0, -2, 1));

        TextView badge = text(k.karar.name().replace("_", " "), 12, true, Color.WHITE);
        badge.setGravity(Gravity.CENTER);
        badge.setPadding(dp(8), dp(5), dp(8), dp(5));
        badge.setBackground(round(colorForKarar(k.karar), 20));
        top.addView(badge);
        box.addView(top);

        box.addView(line("Risk", k.risk.name()));
        box.addView(line("İşlem fikri", k.islemFikri));
        box.addView(line("Sanal broker", broker.bekleyenVarMi(k.sembol) ? "15 dk onay bekliyor" : (k.sanalBrokerAdayi ? "Aday" : "Açılmaz")));
        box.addView(small(k.aciklama));

        box.setOnClickListener(v -> {
            seciliSembol = k.sembol;
            showHisseDetay(k.sembol);
        });
        return box;
    }


    private void tekSembolTest(final String sembol) {
        final String apiKey = prefs.getString("twelve_api_key", "").trim();
        if (apiKey.isEmpty()) {
            Toast.makeText(this, "Önce Ayar ekranından Twelve Data API key kaydet.", Toast.LENGTH_LONG).show();
            showAyarlar();
            return;
        }
        if (taramaDevamEdiyor) return;
        taramaDevamEdiyor = true;
        showAnaRadar();
        new Thread(() -> {
            MiniRadarSonuc sonuc = new MiniBist30Radar().tekSembolTwelveDataTest(sembol, apiKey);
            runOnUiThread(() -> {
                sonRadar = sonuc;
                canliTwelveData = true;
                taramaDevamEdiyor = false;
                bekleyenleriYenidenKur();
                Toast.makeText(this, sembol + " test bitti.", Toast.LENGTH_SHORT).show();
                showAnaRadar();
            });
        }).start();
    }

    private void showHisseDetay(String sembol) {
        content.removeAllViews();
        seciliSembol = sembol;
        MiniKararSonuc k = kararBul(sembol);

        content.addView(sectionTitle("Hisse Detay"));
        if (k == null) {
            content.addView(infoCard("Hisse: " + sembol, "Karar bulunamadı."));
            return;
        }

        content.addView(infoCard("Hisse: " + k.sembol,
                "Karar: " + k.karar.name().replace("_", " ") + "\n" +
                "Risk: " + k.risk.name() + "\n" +
                "Giriş: " + MiniFormat.fiyat(k.girisFiyati) + "\n" +
                "Stop: " + MiniFormat.fiyat(k.stopFiyati) + "\n" +
                "Hedef 1: " + MiniFormat.fiyat(k.hedef1Fiyati) + "\n" +
                "Hedef 2: " + MiniFormat.fiyat(k.hedef2Fiyati) + "\n" +
                "Program yorumu: " + k.aciklama));

        if (k.karar == KararEtiketi.ONAYLI_AL) {
            content.addView(infoCard("Bildirim metni", bildirim.onayliAlMetni(k.sembol, k.girisFiyati, k.stopFiyati, k.hedef1Fiyati, k.hedef2Fiyati)));
        }
    }

    private void showSanalBroker() {
        content.removeAllViews();
        content.addView(sectionTitle("Sanal Broker"));
        content.addView(infoCard("Özet",
                "Sanal Bakiye: " + MiniFormat.tl(broker.bakiye) + "\n" +
                "Bekleyen Sinyal: " + broker.bekleyenler.size() + "\n" +
                "Açık İşlem: " + broker.aciklar.size() + "\n" +
                "Kapanan İşlem: " + broker.kapananlar.size()));

        boolean bekleyenAktif = false;
        for (BekleyenSinyal s : broker.bekleyenler) if (s.durum == BekleyenSinyalDurumu.ON_BES_DK_BEKLIYOR) bekleyenAktif = true;
        TextView onayla = actionButton(bekleyenAktif ? "15 dk kontrolü simüle et ve pozisyon aç" : "Bekleyen aktif sinyal yok", bekleyenAktif ? GREEN : Color.rgb(125,135,150));
        onayla.setEnabled(bekleyenAktif);
        onayla.setOnClickListener(v -> {
            Toast.makeText(this, broker.bekleyenleriOnaylaVePozisyonAc(), Toast.LENGTH_SHORT).show();
            showSanalBroker();
        });
        content.addView(onayla);

        boolean acikVar = !broker.aciklar.isEmpty();
        TextView hedef = actionButton(acikVar ? "Demo fiyat güncelle: Hedef 1 kapat" : "Açık pozisyon yok", acikVar ? BLUE : Color.rgb(125,135,150));
        hedef.setEnabled(acikVar);
        hedef.setOnClickListener(v -> {
            Toast.makeText(this, broker.demoFiyatGuncelle(), Toast.LENGTH_SHORT).show();
            showSanalBroker();
        });
        content.addView(hedef);

        if (!broker.bekleyenler.isEmpty()) {
            StringBuilder sb = new StringBuilder();
            for (BekleyenSinyal s : broker.bekleyenler) {
                sb.append(s.sembol).append(" — ").append(s.durum.name()).append("\n");
            }
            content.addView(infoCard("Bekleyen sinyaller", sb.toString()));
        }

        if (!broker.aciklar.isEmpty()) {
            StringBuilder sb = new StringBuilder();
            for (BrokerPozisyon p : broker.aciklar) {
                sb.append(p.sembol).append(" — AÇIK — Giriş: ").append(MiniFormat.fiyat(p.giris)).append("\n");
            }
            content.addView(infoCard("Açık işlemler", sb.toString()));
        }

        if (!broker.kapananlar.isEmpty()) {
            StringBuilder sb = new StringBuilder();
            for (BrokerPozisyon p : broker.kapananlar) {
                sb.append(p.sembol).append(" — ").append(p.durum.name()).append(" — Net: ").append(MiniFormat.tl(p.netKarZarar)).append("\n");
            }
            content.addView(infoCard("Kapanan işlemler", sb.toString()));
        }
    }

    private void showAyarlar() {
        content.removeAllViews();
        content.addView(sectionTitle("Ayarlar"));

        LinearLayout keyCard = card();
        keyCard.addView(text("Twelve Data API Key", 18, true, TEXT));
        EditText api = new EditText(this);
        api.setSingleLine(true);
        api.setHint("API key gir");
        api.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);
        api.setText(prefs.getString("twelve_api_key", ""));
        keyCard.addView(api);

        TextView save = actionButton("API Key Kaydet", GREEN);
        save.setOnClickListener(v -> {
            prefs.edit().putString("twelve_api_key", api.getText().toString().trim()).apply();
            Toast.makeText(this, "API key kaydedildi", Toast.LENGTH_SHORT).show();
        });
        keyCard.addView(save);
        content.addView(keyCard);

        content.addView(infoCard("Piyasa evreni", "Aktif: BIST30\nBIST50: Sonraki faz\nBIST100: Sonraki faz"));
        content.addView(infoCard("Sanal broker ayarları", "Sanal bakiye: " + MiniFormat.tl(100000) + "\nİşlem başı sanal tutar: " + MiniFormat.tl(10000) + "\nMaksimum açık işlem: 3\nGünlük maksimum işlem: 3\nRisk modu: Temkinli"));
        content.addView(infoCard("Bildirim", "Uygulama içi bildirim: Aktif\nEmail: Metin üretilecek\nWhatsApp: Otomatik gönderim yok, manuel paylaşım metni üretilecek"));
    }

    private MiniKararSonuc kararBul(String sembol) {
        for (MiniKararSonuc k : sonRadar.kararlarOku()) if (k.sembol.equals(sembol)) return k;
        return null;
    }

    private TextView actionButton(String label, int color) {
        TextView b = text(label, 15, true, Color.WHITE);
        b.setGravity(Gravity.CENTER);
        b.setPadding(dp(12), dp(11), dp(12), dp(11));
        b.setBackground(round(color, 14));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, 0, 0, dp(10));
        b.setLayoutParams(lp);
        return b;
    }

    private LinearLayout card() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(14), dp(12), dp(14), dp(12));
        box.setBackground(round(CARD, 18));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, 0, 0, dp(10));
        box.setLayoutParams(lp);
        return box;
    }

    private TextView sectionTitle(String s) {
        TextView t = text(s, 19, true, TEXT);
        t.setPadding(dp(4), dp(6), dp(4), dp(8));
        return t;
    }

    private LinearLayout infoCard(String title, String body) {
        LinearLayout box = card();
        box.addView(text(title, 17, true, TEXT));
        TextView b = text(body, 14, false, MUTED);
        b.setPadding(0, dp(6), 0, 0);
        box.addView(b);
        return box;
    }

    private TextView line(String k, String v) {
        TextView t = text(k + ": " + v, 14, false, TEXT);
        t.setPadding(0, dp(3), 0, 0);
        return t;
    }

    private TextView small(String s) {
        TextView t = text(s, 13, false, MUTED);
        t.setPadding(0, dp(8), 0, 0);
        return t;
    }

    private TextView text(String s, int sp, boolean bold, int color) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        t.setTextScaleX(1.0f);
        t.setLetterSpacing(0.0f);
        t.setIncludeFontPadding(true);
        if (android.os.Build.VERSION.SDK_INT >= 23) {
            t.setHyphenationFrequency(Layout.HYPHENATION_FREQUENCY_NONE);
            t.setBreakStrategy(Layout.BREAK_STRATEGY_SIMPLE);
        }
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private GradientDrawable round(int color, int radius) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(radius));
        return g;
    }

    private int colorForKarar(KararEtiketi karar) {
        if (karar == KararEtiketi.ONAYLI_AL) return GREEN;
        if (karar == KararEtiketi.IZLE || karar == KararEtiketi.BEKLE) return AMBER;
        if (karar == KararEtiketi.VERI_YETERSIZ || karar == KararEtiketi.UZAK_DUR) return RED;
        return BLUE;
    }

    private String fmt(double v) {
        return String.format(java.util.Locale.US, "%.2f", v);
    }

    private int dp(int v) {
        return (int)(v * getResources().getDisplayMetrics().density + 0.5f);
    }
}
