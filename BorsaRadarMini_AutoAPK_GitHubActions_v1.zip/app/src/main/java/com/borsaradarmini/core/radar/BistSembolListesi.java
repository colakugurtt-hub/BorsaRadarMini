package com.borsaradarmini.core.radar;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class BistSembolListesi {
    private static final List<String> BIST30 = Collections.unmodifiableList(Arrays.asList(
            "AKBNK", "ALARK", "ASELS", "ASTOR", "BIMAS", "EKGYO", "ENKAI", "EREGL", "FROTO", "GARAN",
            "GUBRF", "HEKTS", "ISCTR", "KCHOL", "KONTR", "KOZAA", "KOZAL", "KRDMD", "PETKM", "PGSUS",
            "SAHOL", "SASA", "SISE", "TCELL", "THYAO", "TOASO", "TUPRS", "YKBNK", "ARCLK", "DOHOL"
    ));

    public List<String> getir(BistEvreni evren) {
        if (evren == BistEvreni.BIST30) return BIST30;
        return BIST30;
    }
}
