package com.borsaradarmini.core.broker;

import com.borsaradarmini.core.finance.*;
import java.util.ArrayList;
import java.util.List;

public class MiniSanalBroker {
    public double bakiye = 100000.0;
    public final List<BekleyenSinyal> bekleyenler = new ArrayList<>();
    public final List<BrokerPozisyon> aciklar = new ArrayList<>();
    public final List<BrokerPozisyon> kapananlar = new ArrayList<>();
    private final MiniFinansMotoru finans = new MiniFinansMotoru();

    public void bekleyenSinyalEkle(BekleyenSinyal s) {
        if (!bekleyenVarMi(s.sembol) && !acikPozisyonVarMi(s.sembol)) bekleyenler.add(s);
    }

    public boolean bekleyenVarMi(String sembol) {
        for (BekleyenSinyal s : bekleyenler) if (s.sembol.equals(sembol) && s.durum == BekleyenSinyalDurumu.ON_BES_DK_BEKLIYOR) return true;
        return false;
    }

    public boolean acikPozisyonVarMi(String sembol) {
        for (BrokerPozisyon p : aciklar) if (p.sembol.equals(sembol) && p.durum == PozisyonDurumu.ACIK) return true;
        return false;
    }

    public String bekleyenleriOnaylaVePozisyonAc() {
        int acilan = 0;
        for (BekleyenSinyal s : bekleyenler) {
            if (s.durum == BekleyenSinyalDurumu.ON_BES_DK_BEKLIYOR) {
                s.durum = BekleyenSinyalDurumu.ONAYLANDI;
                MiniFinansSonuc fs = finans.degerlendir(MiniFinansIstek.al(s.sembol, s.giris, s.stop, s.hedef1, s.hedef2, 10000, 0.0004));
                if (fs.gecerliMi && aciklar.size() < 3) {
                    BrokerPozisyon p = new BrokerPozisyon(s.sembol, s.giris, s.stop, s.hedef1, s.hedef2, fs.adet);
                    aciklar.add(p);
                    s.durum = BekleyenSinyalDurumu.BROKERE_AKTARILDI;
                    acilan++;
                }
            }
        }
        return acilan + " sanal pozisyon açıldı.";
    }

    public String demoFiyatGuncelle() {
        int kapanan = 0;
        List<BrokerPozisyon> kapat = new ArrayList<>();
        for (BrokerPozisyon p : aciklar) {
            double fiyat = p.hedef1;
            MiniFinansSonuc fs = finans.degerlendir(MiniFinansIstek.al(p.sembol, p.giris, p.stop, p.hedef1, p.hedef2, 10000, 0.0004));
            p.durum = PozisyonDurumu.HEDEF_1_GELDI;
            p.netKarZarar = fs.hedef1NetKar;
            bakiye = Math.round((bakiye + p.netKarZarar) * 100.0) / 100.0;
            kapat.add(p);
            kapanan++;
        }
        aciklar.removeAll(kapat);
        kapananlar.addAll(kapat);
        return kapanan + " pozisyon hedef 1 ile kapandı.";
    }
}
