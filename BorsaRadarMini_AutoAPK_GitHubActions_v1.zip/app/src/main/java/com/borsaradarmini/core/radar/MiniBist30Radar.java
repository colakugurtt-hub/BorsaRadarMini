package com.borsaradarmini.core.radar;

import com.borsaradarmini.core.data.*;
import com.borsaradarmini.core.decision.*;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class MiniBist30Radar {
    private final BistSembolListesi sembolListesi = new BistSembolListesi();
    private final MiniVeriMotoru veriMotoru = new MiniVeriMotoru();
    private final MiniKararMotoru kararMotoru = new MiniKararMotoru();

    public MiniRadarSonuc tara() { return taraDemo(); }
    public MiniRadarSonuc taraDemo() { return tara(false, null); }
    public MiniRadarSonuc taraTwelveData(String apiKey) { return tara(true, apiKey); }


    public MiniRadarSonuc tekSembolTwelveDataTest(String sembol, String apiKey) {
        List<MiniKararSonuc> tek = new ArrayList<>();
        MiniVeriSonuc veri = veriMotoru.twelveDataCanli(sembol, apiKey);
        tek.add(kararMotoru.kararVer(veri));
        return new MiniRadarSonuc(tek, ozet(tek));
    }

    private MiniRadarSonuc tara(boolean canli, String apiKey) {
        List<MiniKararSonuc> ham = new ArrayList<>();
        for (String sembol : sembolListesi.getir(BistEvreni.BIST30)) {
            MiniVeriSonuc veri = canli ? veriMotoru.twelveDataCanli(sembol, apiKey) : veriMotoru.demoTwelveData(sembol);
            ham.add(kararMotoru.kararVer(veri));
        }
        List<MiniKararSonuc> adaylar = new ArrayList<>();
        for (MiniKararSonuc k : ham) if (k.karar == KararEtiketi.AL_ADAYI && k.sanalBrokerAdayi) adaylar.add(k);
        adaylar.sort(Comparator.comparingDouble((MiniKararSonuc k) -> k.puan).reversed());
        List<String> ilkUc = new ArrayList<>();
        for (int i = 0; i < adaylar.size() && i < 3; i++) ilkUc.add(adaylar.get(i).sembol);
        List<MiniKararSonuc> finalList = new ArrayList<>();
        for (MiniKararSonuc k : ham) {
            if (ilkUc.contains(k.sembol)) finalList.add(k.onayliAlYap());
            else if (k.karar == KararEtiketi.AL_ADAYI) finalList.add(k.alAdayiOlarakBirak("İlk 3 dışında kaldı."));
            else finalList.add(k);
        }
        finalList.sort(Comparator.comparingDouble((MiniKararSonuc k) -> k.puan).reversed());
        return new MiniRadarSonuc(finalList, ozet(finalList));
    }

    private MiniRadarOzet ozet(List<MiniKararSonuc> kararlar) {
        int on=0, al=0, iz=0, be=0, uz=0, vy=0;
        for (MiniKararSonuc k : kararlar) {
            if (k.karar == KararEtiketi.ONAYLI_AL) on++;
            else if (k.karar == KararEtiketi.AL_ADAYI) al++;
            else if (k.karar == KararEtiketi.IZLE) iz++;
            else if (k.karar == KararEtiketi.BEKLE) be++;
            else if (k.karar == KararEtiketi.UZAK_DUR) uz++;
            else if (k.karar == KararEtiketi.VERI_YETERSIZ) vy++;
        }
        return new MiniRadarOzet(kararlar.size(), on, al, iz, be, uz, vy);
    }
}
