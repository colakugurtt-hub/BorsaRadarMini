package com.borsaradarmini.core.data;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MiniTwelveDataParser {
    private static final Pattern OBJ = Pattern.compile("\\{[^{}]*\\}");
    private static final Pattern FIELD_QUOTED = Pattern.compile("\\"([^\\"]+)\\"\\s*:\\s*\\"([^\\"]*)\\"");
    private static final Pattern FIELD_UNQUOTED = Pattern.compile("\\"([^\\"]+)\\"\\s*:\\s*([^,}]+)");

    public MiniVeriSonuc parseTimeSeries(String anaSembol, String kullanilanFormat, String json) {
        if (json == null || json.trim().isEmpty()) return MiniVeriSonuc.hata(anaSembol, kullanilanFormat + " -> Twelve Data boş cevap döndürdü.");
        String lower = json.toLowerCase();
        if (lower.contains("\"status\":\"error\"") || lower.contains("\"code\"")) {
            return MiniVeriSonuc.hata(anaSembol, kullanilanFormat + " -> " + hataMesaji(json));
        }
        int valuesIdx = json.indexOf(""values"");
        if (valuesIdx < 0) {
            String kisa = json.length() > 180 ? json.substring(0, 180) + "..." : json;
            return MiniVeriSonuc.hata(anaSembol, kullanilanFormat + " -> values alanı yok. Cevap: " + kisa);
        }
        String part = json.substring(valuesIdx);
        Matcher om = OBJ.matcher(part);
        List<MiniMumVerisi> mumlar = new ArrayList<>();
        while (om.find()) {
            String obj = om.group();
            Double open = fieldDouble(obj, "open");
            Double high = fieldDouble(obj, "high");
            Double low = fieldDouble(obj, "low");
            Double close = fieldDouble(obj, "close");
            Long volume = fieldLong(obj, "volume");
            if (open != null && high != null && low != null && close != null) {
                if (volume == null || volume <= 0) volume = 1L;
                MiniMumVerisi m = new MiniMumVerisi(open, high, low, close, volume);
                if (m.gecerliMi()) mumlar.add(m);
            }
        }
        if (mumlar.size() < 5) return MiniVeriSonuc.hata(anaSembol, kullanilanFormat + " -> Yeterli mum yok. Bulunan mum: " + mumlar.size());
        Collections.reverse(mumlar);
        return new MiniVeriSonuc(anaSembol, VeriKaynagi.TWELVE_DATA, VeriDurumu.BASARILI, mumlar, "Twelve Data başarılı. Kullanılan sembol formatı: " + kullanilanFormat, true);
    }

    private String hataMesaji(String json) {
        String message = fieldString(json, "message");
        String code = fieldString(json, "code");
        String status = fieldString(json, "status");
        StringBuilder sb = new StringBuilder();
        if (status != null) sb.append("status=").append(status).append(" ");
        if (code != null) sb.append("code=").append(code).append(" ");
        if (message != null) sb.append("message=").append(message);
        if (sb.length() == 0) {
            String kisa = json.length() > 180 ? json.substring(0, 180) + "..." : json;
            return "Twelve Data hata cevabı: " + kisa;
        }
        return sb.toString().trim();
    }

    private String fieldString(String obj, String name) {
        Matcher q = FIELD_QUOTED.matcher(obj);
        while (q.find()) if (name.equals(q.group(1))) return q.group(2);
        Matcher u = FIELD_UNQUOTED.matcher(obj);
        while (u.find()) if (name.equals(u.group(1))) return u.group(2).replace(""", "").trim();
        return null;
    }
    private Double fieldDouble(String obj, String name) { try { String s=fieldString(obj,name); return s==null?null:Double.parseDouble(s); } catch(Exception e) { return null; } }
    private Long fieldLong(String obj, String name) { try { String s=fieldString(obj,name); return s==null?null:Math.round(Double.parseDouble(s)); } catch(Exception e) { return null; } }
}
