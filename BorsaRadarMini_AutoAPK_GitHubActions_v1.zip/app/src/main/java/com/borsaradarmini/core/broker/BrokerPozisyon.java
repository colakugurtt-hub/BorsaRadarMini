package com.borsaradarmini.core.broker;

public class BrokerPozisyon {
    public final String sembol;
    public final double giris;
    public final double stop;
    public final double hedef1;
    public final double hedef2;
    public final int adet;
    public PozisyonDurumu durum;
    public double netKarZarar;

    public BrokerPozisyon(String sembol, double giris, double stop, double hedef1, double hedef2, int adet) {
        this.sembol = sembol;
        this.giris = giris;
        this.stop = stop;
        this.hedef1 = hedef1;
        this.hedef2 = hedef2;
        this.adet = adet;
        this.durum = PozisyonDurumu.ACIK;
        this.netKarZarar = 0;
    }
}
