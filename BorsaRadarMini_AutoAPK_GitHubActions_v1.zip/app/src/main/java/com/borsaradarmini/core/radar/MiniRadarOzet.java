package com.borsaradarmini.core.radar;

public class MiniRadarOzet {
    public final int toplam;
    public final int onayliAl;
    public final int alAdayi;
    public final int izle;
    public final int bekle;
    public final int uzakDur;
    public final int veriYetersiz;

    public MiniRadarOzet(int toplam, int onayliAl, int alAdayi, int izle, int bekle, int uzakDur, int veriYetersiz) {
        this.toplam = toplam;
        this.onayliAl = onayliAl;
        this.alAdayi = alAdayi;
        this.izle = izle;
        this.bekle = bekle;
        this.uzakDur = uzakDur;
        this.veriYetersiz = veriYetersiz;
    }

    public String sadeMetin() {
        return "Bugünkü durum:\nPiyasa temkinli.\n\nBIST30 içinde " + onayliAl + " hisse ONAYLI AL, "
                + alAdayi + " hisse AL adayı, " + izle + " hisse izlenebilir, " + bekle
                + " hisse bekle, " + uzakDur + " hisse uzak dur, " + veriYetersiz + " hisse veri yetersiz.";
    }
}
